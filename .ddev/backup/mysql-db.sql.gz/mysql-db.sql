-- MariaDB dump 10.19-11.4.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.4.8-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1760768557,1760768557,0,0,0,0,2,'{\"003b239b89613a68eedbf863d931c24c8733b025\":{\"identifier\":\"t3information\"},\"ce6299a0a66f0065e47f85c3d16cddc6cd59fcd9\":{\"identifier\":\"docGettingStarted\"}}','6886391e5c3e0bd2b07c8c53d20963ef7714e062','My dashboard'),
(2,0,1760803005,1760803005,0,0,0,0,3,'{\"8e9aa34a70bded316477400f7de5037a15fbb9d9\":{\"identifier\":\"t3information\"},\"2559eeb527f826972e48361f5b7e65d40a07b4cf\":{\"identifier\":\"docGettingStarted\"}}','05bac6bb87b069637b281add544ec225ba87ba5a','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('7cdbe213991b328a0976922adb91e81b9f28ecb08eeffee91d62e7e0d1dddf50','[DISABLED]',3,1760940406,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2e90edfd1d63a8c27c89e88aa3767b06792c9ed987b5e7ec87c771fe48371e90\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1760768507,1760768507,0,0,0,0,NULL,'default','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$QmUyaE95dHhrUXkucHFYUA$9+1zUDwEgobE4P838IMrX0w0kw1y8us475WLMa66QqI','',0,NULL,'','','',1,3,NULL,1,NULL,'',NULL,0,NULL),
(3,0,1760855823,1760802880,0,0,0,0,NULL,'default','a:22:{s:10:\"moduleData\";a:11:{s:28:\"dashboard/current_dashboard/\";s:40:\"05bac6bb87b069637b281add544ec225ba87ba5a\";s:23:\"backend_user_management\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"deac478137dd48a97e299bd046412e21\";a:5:{i:0;s:18:\"This is a testpage\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=afca06da2b09dd3d86a013264d6bad2ebcf26a71&id=2#element-tt_content-2\";}}i:1;s:32:\"deac478137dd48a97e299bd046412e21\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:4:{s:32:\"629911c017052e9e049ce359020150c0\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:7;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=ebfdf72996b7034aef2173fe1316f0044d0aa70c&id=2\";}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:5:{i:0;s:22:\"Das ist eine Testseite\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=ffdd3395577fae687f1d7045b71fba66b2909d0a&id=1#element-tt_content-1\";}s:32:\"af6a208f792a83220f87a953a62a081a\";a:5:{i:0;s:27:\"This is a testpage (copy 1)\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=ebfdf72996b7034aef2173fe1316f0044d0aa70c&id=1#element-tt_content-6\";}s:32:\"2258d9587529a9ea12f96ce7d90372b3\";a:5:{i:0;s:17:\"Zweite Unterseite\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:3;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=ffdd3395577fae687f1d7045b71fba66b2909d0a&id=3\";}}s:9:\"clipboard\";a:5:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";s:6:\"normal\";a:2:{s:2:\"el\";a:1:{s:12:\"tt_content|1\";s:1:\"1\";}s:4:\"mode\";s:4:\"copy\";}}s:12:\"system_dbint\";a:5:{s:8:\"function\";s:8:\"refindex\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:16:\"extensionmanager\";a:1:{s:6:\"filter\";s:5:\"Local\";}s:17:\"web_linkvalidator\";a:4:{s:6:\"action\";s:6:\"report\";s:15:\"report_external\";s:1:\"0\";s:11:\"report_file\";s:1:\"0\";s:9:\"report_db\";s:1:\"0\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:15:\"1:/user_upload/\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:11:{s:28:\"dashboard/current_dashboard/\";s:40:\"434e155181f3a3ed368ebdf967ca655d9bf14344\";s:23:\"backend_user_management\";s:40:\"aabcb53c61dd55c994157455ac1b21b33ca9bccd\";s:10:\"FormEngine\";s:40:\"81dfa52caed5232205fc0d13d003113bcae3dba9\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"81dfa52caed5232205fc0d13d003113bcae3dba9\";s:16:\"opendocs::recent\";s:40:\"aabcb53c61dd55c994157455ac1b21b33ca9bccd\";s:9:\"clipboard\";s:40:\"a4b69b6d6b5dd972fde305602075940c52c920d5\";s:12:\"system_dbint\";s:40:\"a4b69b6d6b5dd972fde305602075940c52c920d5\";s:10:\"system_log\";s:40:\"a4b69b6d6b5dd972fde305602075940c52c920d5\";s:16:\"extensionmanager\";s:40:\"a4b69b6d6b5dd972fde305602075940c52c920d5\";s:17:\"web_linkvalidator\";s:40:\"a4b69b6d6b5dd972fde305602075940c52c920d5\";s:16:\"browse_links.php\";s:40:\"a4b69b6d6b5dd972fde305602075940c52c920d5\";}s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:999;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}s:17:\"systeminformation\";s:40:\"{\"system_log\":{\"lastAccess\":1760853850}}\";s:11:\"colorScheme\";s:4:\"auto\";s:14:\"indexed_search\";a:2:{s:6:\"action\";s:9:\"statistic\";s:9:\"arguments\";a:4:{s:10:\"controller\";s:14:\"Administration\";s:6:\"action\";s:9:\"statistic\";s:5:\"token\";s:40:\"1ac28d363a9c8b68244cfde4cc966c9af5640719\";s:2:\"id\";s:1:\"1\";}}s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:4:\"lang\";s:0:\"\";s:11:\"startModule\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:10:\"copyLevels\";s:0:\"\";s:18:\"resetConfiguration\";s:0:\"\";s:12:\"mfaProviders\";s:0:\"\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:5:\"theme\";s:6:\"modern\";}',0,NULL,'','johndoe','$argon2id$v=19$m=65536,t=16,p=1$SVRtdDRjWGRwZmNMODMvcg$Rpa9/xaLRQHcJDkF4SzNfEySt0qifHo5pifLT05TEFQ','',1,NULL,'','johm@doe.com','John Doe',1,3,'readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',1,NULL,'',NULL,1760930208,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(3,'redirects_7a9250be94150a6c39b9b0c2bd037f189af942f8',1761366814,'x�K�2���\0O�'),
(4,'redirects_df58248c414f342c81e056b40bee12d17a08bf61',1761366814,'x�K�2���\0O�'),
(5,'1_40e82e9d96593586',1761449614,'x��Y�n����m��hd���n�ٙ����`�]t�%[�P�JRv�����>B_���O�sH˱�2�EQ��X�~�����q�k��8��މ,8q�č���Pڀ���8>�����7�Yn9n\r�����(��4<�>�,giε;\nj;	���5|���YR��d���P��\Z\rpc�۩*Z�Ϯra�\"`��Rs��xЊ�}2Q�JhQNY����b5�3dw4���D0UAɌ�u\n����^�����̕�F��\n.傥\Z��\Z��M�]^s�s���2cR�P\Z��K��}����.��k�SU-���u����^�7`j�-�͞ߠ9F��հƆ�6��dI���#��A5g�D�[�s�PĴHj?`1L�2q�E��m��Q+)R��(Q��<�5LFA����{�,9NS����n�{�K\0��\0���0�ΐ�D>#���M�:\0�g���)$��V���*�,^�wJYc5�؟0���S�|Ɛ�!���Qp�<�l���DB��I9\nΞ� �B�p��Q0��[��(���W�[�3�Ji�F:��G�_���&B�r	���teM��T�ٛ()�|E[iL>m�@Mc��\ZG�njJ�w��G� n��+\\\ra��p\r�8���(��V�zB��`r\0�J�>�*Z�GjLt��ңt�����;H��~\'�����`����7�Ã�Ѡsp�X��h��N%=C�jQ�e�*��8��Q����3(T;��	�x�=�G���(��\n�xy��/�\r�Ja�-fX����tb�����ެ)\\G0�*fK�*#\n^�+�0Q�bYGA��Ki�g,�?�������M�+?�S�LCb\r-���z,y&V�{��:�#�*�D��U��k�o���c��lʲj:��sO��[&f9M�I�+k3\\O���tYW�f![V�\0률��Oɕ�{�<Z���	��ōJ�Pܮ�\r�����\r��Π�ݾ���RN �6(��x{x#.��&��P��^�vYX�-�(y\ny��\"	{�����]���u��X�b��a���t������Ұ.lR��a,Ȓ���Q}�z^m,�����w�{�y\\�Z@V㎣~���_�\'R:j~G�i��\'�y�7�Y[���I����\Z�<�g��\Z?�\r������h|��B�q<��OS\'b����l�@7�����/b?�j��K�K~���C��,��q��W�ր����dt7����5������%d?��mJ�T�����j\ZF�{\\�䯽#�S�۟*�9���):�4����7���i�I#;v�O;A�݆���~�:���qc@����0Y�v�F҄�e���M^K�|��wn�w���ag���p<�\'0Q\ZO�x����>���r\"�A��o�97��_�\ZO�k��a��2sW^�%�O��\'�ݲn{���*�Z�(w��I�������]3O%q�[���.�9hh���|�	��{?���E\Z��R�\n�L�S�Q��(��TK��VRrG�G�k��=Qh�St]6�4k\n�i�ʢ�3�\n�cǐ�E�p���ty#�*Sa@.�R��d�+e`�q9�Ө39��Jy($xP�\n�5����cj�2u����$��$h�4\'%\Z,��:���L�3�L{U�B�M\0�GG��7�TT���nCwu���d��	�{z�?�ӗ��Z.n����]�p��U]\Z���B��CU�k3��sa�E�f�ܥ���t�*O���?�ꔀT�O��Su�S��y�e�0rAgL�J�Q�;�_ІQ��WOm�=��T��iNry���*EK�����6\'C��U-��s�zH�_��M���v�KxL E����̕���+�\\�|���\"�J	�;��F�a8m�-����񜽯#Z�iS��g	��-�ߠ�0��\0Qp]#]K��J6�E�7m4OFm6��_h�</�^�����=v{���������	BE��/X�\\x��8��A�u1�/pN����P��Y�p�L�\"�I9S�p��_��2At�7^�?�6��8�����RX�W���}{�\n�.l?|^5$Tr\\�j�ӵo�ҁ�E��s���\\u����[8�h٭�\\G�Z���s|�@\Z����Gt����0������+\\�>݂w�o�Ù�͙w(emv߷���z��h�K\r����w�ޞ��|{�����|��:[�_h5�v�d[��NP�GXxQ����A���u���~P��K�d\\Z��+�}d�PR��70��^��/�ں�©��ڸ�4�8��_��c��\\��S�%�7��9��u�a�M%4�Ʀ��c����\0N�mm'),
(6,'2_3683d4a9501ede9b',1761452090,'x��Y�r����pLg���(ɖ-Ӓ��w����<g7m�׹ɕ�3H�\0(Y��Lޡ_�G�k�Q�$�H����wi>�=c����o`��^7����qP��Yp*���kIUa��~\r��`�����/_����doD?L�b6�+P�l����`9K�\\�㠲�p�{�ga��>I*!3���J�ޠ�\rt\'U���\'�sa�\"`�Z�%hp<h��2Q�RhQ�X	����b5�3dw4���T0UB���t\n�̏���������9,��A��\n.劥\Z��\Z�M	�]�p���=�EƤH�0�_h5����G_\\^tZ�SU����-띜�~�?`j�-��^ܢ9F����bCb;��dI�X�@�h�j΋��9����!�i�T����li�(��Rt��E{aH���A�r�	�\\�tD�AW��?Ȓ�4����I����� `�d�it�\\&���w�b0�(.G8#l��m.)��&/�6�Q�ŵ�~��5V�}��E�n����_*��a�C����HX������\rW��3@p�U�E�U���ڢ]X�J��Rdv>�\0G���o�!4)�0�m	�*���D�����R-״����v5�,v�mq�����&�;�voL�0nY�K�a��?8�BlS^�ME��Ʈ$�9�]��!y�1�\Zw{�t��t0�{�dp<8�&�~��Lӣ��w|��G�~�r�Gät*��T���񓫬\"�N��F��`�A�:��C�ă��A�+�R)(YMF�8��߀�&��b�� �-_�+\'6ʹ(:�MKa���/\r�����a�ϣ�De�:���|�k�,��t_$\\3��m�y �3��Bb\r-��zԼ�?k~�	�6�#�*�D��u<���o��ld1mʲj6���v��	X�-Sw�qR��@���-&�yAWUI��:��=�̃J��=@�тlL�$-�U�<x�l `��e�m���J�=��eV�$�%�#�n���z��;(D��vYX�-�(xry�Ke��}�\'gaw7=�[�l)Z�C��2�[.P����!�;�,t�P�D�gC��@�4|8�C�KÏ}/ʷ��u���0nC������x\"�����9o�Nj&u+�f���V����5��z�����o��(�w�O��Ўc7�;P�_M�� �M��Aφ�Ɠq���F�GQ%?z���%����r�ಓ�/%���2n���0�������m	�t��p\n�!�9lS�����=�}M����-�{a��w�p�\n�s]t�i�O����%��i�I-;��O;O�{\rMi�àU@Cz�Ƅ�q{���dG�G�Z֔�6���ՔW��_t����m�-�JU6�֟�-�~S����*���S<:����7x��~RN�rrnn�N���$���f��r\Z:�\Z�=T�����>Å��9���X!%+��D1C�J�B\nOU�O�ʑ�;\"<��@�0l�B+�R�@R����Z /-j<GN(�>vY��+�����j�L��b����_�Ke`�q��+Ө3s�鉊d($x��\n�5����]�csv^�*�����b�k:Z5��\r&)���B!,�\r�3�J<w���h<�E+�T����*��+K���Lgk��)i�\"�\n��W��7��(T5�\'O]m�X1\nc��m��xf��Z\n��_�JR����8-�_BF�3`U�r�O\\�H�e�@\09U?K�=WTY��̈́\"�R	�,�ԨP:�ιE���{cc�+D��U:��6������q��W�\0�3pUM]I��\n���tޔy=����X��OL������>;���gw�_�쏯.N*�G��|���L�3�خq��Tac>8e��;s�0���p��\n�v�P�p�5�O�\\� �7��P<a��9�g�;�=��]������y������>ٳ0�t�sK+�/*p�Xǲ^&����~��]�NB���JU�L]c��Tf����%X�U�\"�b䐪	R����?�n��ctw��a���	�\n����b��*�th�9P9��\"�J�}:Lx�v!FY���hR;���O[mY�7o��Z֛��R��zu�_��D�[W?��M@ِP�SJp����P]�T���?��)	�,(��x�}my����]W�=V���ֺ��5�cg�#:]_W��*b�����ט�}�	Ny܍��{�6{ޡ�VS��x9��ף۶�a���o�^]�=������|�w�:[_j����)ݸ]�9E-h\"����z�G�����I�����c�]Y\\W����RI����W���gye]��LII�L�0�8�ӟ��D�Fq�g�%bR4��<����q�Uh0�M��~m��_NǨ�'),
(7,'4_f34f0d1e44beded4',1761452092,'x��Y�r�����Lg�(ɒ/��^����:�Y��f���<�	\0%k2��;�O�}�>J���\0�,�vlo���3��sp\0�ߋ�1�aT|�E��xx�zRUZ(m���a���9����%�m!��1�0���$�2�M@}��i��3.�r��\\������):�a�:�$��KV�O��\0��������*�-!!���Z�ǃV��g!����U�*	�*fP#�@vG�|��4\0S�̨Z��N���9/QmA��4/`��5\nVp)W,�����;n*���s�����\"���x]��싯~}q񺻡:U�J�ynY���(�#�f�º��\r�c�*�Z\rlHls�i@�ԊNdY�6�欜)]p�|��I�;,��V&�\"���~W�y�	C��5J��@ O�r\r�I��]e��`�%�i\n�����;�\r�l4��$;L�3�2ь/��k�@q�a�/n\nI�`��0}%����	EY�x�7JYc5�����ȓv|ؐ�!���Ip�<Đ�p����5�9	�^N �C�r���I0ć[�7(�����څ�e��� ]���pr��^�I��IG�V	NeC��x�ٛ))�rM[i�@mW�@�c7�\r�-��g�e�ޙ�6�;��\n�EX�D���;W|�R���\rcWL`���BQEM���D���(=J�<�fG�Q2:�������f�A�~�?<��zG���	��I�T�36��m��PYM��N�� 8�0�Bu3�P�0�G����W4�RPʚ�#/p����3Lt���A�[���NlTpQv?�\r����T���i|Te4�8)�׍��|n\'*[5���g>ٖ|�R�nAW�E�5�?!�T�B9g�<$��bH	�WA���3�様�y��$pD|[E�h���`z���b0CY�P۲���%�l\\�i�q���4�d���2�1���6�O��˺�\rY��̨���F%�� �hA6	f\\��+yB��r6�b��.@nv%�?��e[�$�%�3����z��[(D���;�Q��\Z��\"	�O���}�����dK�!;D�,�,��Ÿۿzo��n5�\Z ۈ�4`������>b=>/�\n|��;Q��<�k�/�	�Ѥ~���_�\'R:j~G��V�vQ�&$\\��J�7ھ�]�秧k���4���޲�Q�o)��3�?h��\\�w��CЯw��Cϖ�g����{���Q-?z���%����R�%���/���2n�e�\r`>>�=�-��K��}@������ö%�?��=���4��H�y��h�#�S��\Z�rAn��:���=\\�	��;�>��#�Ӯy���l8��hK�Z�>�ѹ{R&S���7��s��5㵴M�.x�iے�Tm�^��:^��)�wg�������%��w`�����I9�ߪ���P�BCI\\0V�L^�e\Z��\n�=T�����ý��9���X!%���D9G�*�BJOհϴ*��;\"��\\C�0r�B+�B�@Ҩ)8\n�(*�\Zϐ*��CV�ʩ�Ӧ�*Sa@�:��0X�J�c\\.�ʴ�L�1CQ	\r�$/�Za�f�����؂�U�.���落㶎V�sR��<�x�TF�%C��t�Q�7�j�\nM\0�W2�3,�TT���ꐉ+Z�\Z<�ek�_S�e�PѯD[�aQ�z�\'O]٫\\1\nc��m(�xf�V[\n��_�ZR=��U@-�_BF��`]\n�r�QܭH�e�D\09�F+��+��z��yBq�z�\\jT(fsn&\'���؇\ZQ@�E��1Un}p��\"�5��\0�jk��|��k��Uɖ�H��ɨHl]�b�:<1������=vzy��n�4>�0L��_� T��@/����d�3�دq��Tyc>8e��[s�4���p��J�v�P�p�m�/�B� N����P<a��9�\'�[�Ng7�>�ޖ�n\"����R�*�	ٷv+Q��������jI(I�)�	ͪU8�F�\n���s�����s��~�\r�e�q�T�\"���>�����$W��P�`;c�������A,�88��\n�����ǽ��oq�`{�=J���4Wtx:�i4֧�7ã�W�ߝ�_�;ň}w�R�{�g$���Z-�ug�~�s�<AEh�Ë��������ACO����nri1�-�G�%E�zs�Ю���Em]��TII�.Ti@q�?;M�M��M#J�=$9�S=���a��Gh0�M�Ѡ�6}�/,;'),
(8,'5_391f3d70013d42ba',1761452100,'x��Y�n��^}��@/\ZY�\'�v�3۴��`�]t�%K�P�JRv����i���G�\'�9���N2��v/��\0�H�?~��<��pc�8�y�D��x|�zRUY�l��Ã� &Ͼx}z���V�R�z�a�W�4�*lL@}��Y��3)�r�\\�Ӡ���)z�ga�z�%��KZf�����h���OU��}vUÖ���Z-A��A+^ﳐ���B�*g5�Z���ϐ�� gs\r�T\r3��)�S?7v�+T[��K�KX*}�B�\\ʖ�\Z��\Z�M\r�]^s����*cR�Po*��}���//^�7T��n��ˆϟ���h��|WX���As�PZ�a�\r�mB3\rȒZ���,+�՜Us�Kn���C�\"i|�E7���Qd�Z���Σ^����Q��yVh�O��7�*��Y�<Ma��<�ǣ ��8Ɏ���L4�b�E0�(�D8#���M))��f��t3MBa���k��������I�i{>n���҈�4�	bL�8�DB�V�9\r�^L!�!�*��4��V�\rJ����r�v!`Y+m7H�\"��4������DhR.a:��U�S�!0 n��JJ�\\��\ZCP�v\Z�<v���؆�~Z�H�ymC�c�qe��J��z\n�#Lyͷ������0��`\n\0�J�:Z�JjLt4�������x8N�G��A2\Z\r��<=�#�/�G������x�2��0)�Jz&&բ��8*U֐qF��`+��N0̠T�]�\'L���h?�%�D���f����p�o�g\r]h�����/���\\T��fC�&�)�T%0f:\0Ua�������I��v�mA�~�n�,��t&_$\\3��M��!�9K�XC�A%�n����Ě��gz���ma�Q�:>���k���,e1Km˲*�%�\\9��,㖇�Y\r�qR�����9m2�{A�MMk\Z�U�0�\nJ!��\\�{�̣�4�sIZ\\��	y���@���e�]���J�n�˸-H�J�g�۽�?�γ�P���i�ga#w��)!�\rn�e�����}�����dK�!;D��,�<������{�+t�c]!؅��C_~ J�*���#���Rhc-�G��޻��6��0�K������x\"���w�����xN3w9��jm��Y����\Z�=��iÍ��я�|K�d4>B�G!�8����K�a��>�z�|�4�����7b?�\Z��K��|Z�b����r��\\�?��:/u�l�@u�����ӳٓA�2��$�}\0������Ķ-�����QﮦI�G�͓�F{a��w�p��sCt��b���%��k:���z�9r>�ZQ;�چ�N�\0��:3��5zw��dK::ys*�0��Zs�H�j�-oB7][�V56��xBO!L`�4^���ڔ[#|����@0������ޏ��W�������!4�Dh��-Lb��\0\r}v���]it��pkr|\'�6VH�j�2Q�ȣX�QH�V�s�J���*א1��\n��Z5�4jJ���ڢ�3�\Z�cǐ5e�:�}v�*ȡ�T�-C� U]+{��%oM��3��PH\"���k��w{��-�Ym�����N�9n�hU^�\r&*�\'��Z\",�\r�?�j��׳�h��iA��(��T�L\\�ҿ�`��֜��U�P�B[�aQ�&/�����U���uyJ4��喂!㗪�T��veP�闐Q�:�T¶�>��)�LU �i-1�E�W�q<^(\"��@ϒK�*š�l�-���ܙ{� \n(�l�\"����[ľ��\Z@_m\r;\0���>u#Q��زi�U�=U���XlP�\'&x~su�j��^^��:��/S���W\'�#�K޲�# ��t��5Np��o�g\0��|k.T�q#.VT�ޮJ���W*��)�n�\',�9G��K���f���۲�]�v��1W\nS�:!��n)���U>~�;JaJkB��\r��1���?��\\�=|��\\?�!z�}�r�Jo��B_G���ǒ+�Q�kt;c���#��B,�88��\n�����ǃ��oq�p{�J�=�_j���t��hlH�p�c_~{z~��#��EG��\r�:[�/�Z\\���s\n;AMh��˚�\r��������〪�_�]��b:^���LJ��}�@l�8�i�XW\';UR�U�P���N�sD�fr�s�%bRt��z��;£8���`:��Tb>��_ob<�'),
(9,'3_8430574af61b5cd5',1761452101,'x��Y�n����m��hd�\'�b����6��N0I�.:ŀ��eN(Q%);�b�}��i���G�\'�9���N2��v��\0�H��sxH�ߋ�1�qT<�w\"NE<<u=�*-�6���p|�g_�>����9[�B�:�a���4�2�M@}��Y��3)�r�.�6`�Am��):�ga�:�%��K��O��\0��������j![AB_+�\r��x=d!���e�*P�f3��!��A>��\Z��\nJfT�S`g~n�/QmA�/4/`��5\nVp)�,�����;n*���s�P�/3&E\n���D�ٗ_�>���e��:U�Z�|aY��dz�S�}a]���1B�h����4 Kj�\'�*ATs^Ε.�E>gyL����d+G�]Wj�U:�:aH���F�r\Z�	�B�|\ZD�AW��p0ʒ�4����$�����A��F0N��4:G.���ػf�u\0�+�;~~SH\n+���% ]�(���~��5V���;�<a�\r�_j��7a�C�\n�H�&.����)d9\rW��9 :�*ݢ�*�^]��.�*�m�t%2��f�S��5��M�%L�{B�Jp*-���`��T�-m�1��]O��n�-�>�3�xG��Lj�=�x�k\",T\"�WR�a�+�d�h]���ص�\0���pAd���M���Dǽ�(��<����(���d0��z�yz�E�_�z�Q�h<X��h��N%=�jQ�M*��8��i���\'fP�n���&�<�~I#Q*���$�g?\\����DZ,1D��K~��Fe��i)l#��R���Q��qQ6Q�T:IT��$Vг���Z�%K%z�Ǘ	����pSa*eΒ<$��b	������gb�Oa�S�&pD|WE�h�\r�`v�J��b0!YLH����s�:7��4˸�ab6�d���2�\Z�:���s/貮hC�I�&PA	S��[}�y� �s.I��<!^9X��$����A	��-tɕ�I�A�����w���x�\n�=8��,��}<���ݲH���yػ����{�l)Z�C��2L\\�QI�7�B�r\Z�\r�M�}0���d��~�>b=/�6�%�G������Z�N� �S�t�R<��Q�;��M�e<����Ú��o�CM�[X�j\\�^���5~2�;F?\n�-�������x2ʛWS\'ļ�H;����x2��߈�$��\'/�X�iɋqw����a�S��Hk�Ԭ��	����9ej6{2�;���������	m��h�������j�Dx�l�[�I��\n����*��\rѵ�q>��+<�WtR�c\'��s�|�}b�oh*��\0Zҟ564�kt��ɐ�0h�ͩr���R�y-��Ew���4m�ת�ao��s9^��+��d��������i3���x����rz�U�s�3C�\"f\r%q�X��0u�W��eW8�1��F߯nH�����\n)Ye&�y�4\n)=Ն}�U����\r�\Z2�qCZ����\0�FM��}�EeQ�9rB���c��X;�]v�����T�k��A**�պR�+�6�:�����P�B��^��_����Ktl��+S��wR�q�G��)q�`�B�pR*��`���w5{�&����At**���J��ĕ&�\r�Gٖ�W��D�zT�+��kAX�����SW�*׌�uy\n4�����!�W��Tu�vuN�闐Q�X�®]�*Rd�*@N�Jb@/UW���P���R=K.5�\0��n&\'�����\ZQ@�E�.b���8�:�E�k����ΰ��\\eS�嫒�\"]4�^OF�`�\"��	��\\�zy��./�m9���)�㫗��#��f��`�ә\\��8�%H��1��2t�P��Y�p�XQ%z�\\*I8�&�\\��G�ěYx(�������-Q���eo��j��\n��\\)L�ۄ�[�(VXWs����jH(I�)�	ͪuxH����>���\n��%��������hSp��W����o��\\�B]����N�_9�Gb���WW��}x�<���|�#G�#�PJk�������O@c}�Hs8�}���٫˷g�o/\Zʷop+�ٶ}��R�Zo�o}OQ\rڀ���=����ht���0���^O.-���!2]()�������u��3%%}�P�q������4� t4�+���(��d�\'z��:��8�;��`\Z�G�>����\0jb/');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_40e82e9d96593586','pageId_1'),
(2,'2_3683d4a9501ede9b','pageId_2'),
(3,'4_f34f0d1e44beded4','pageId_4'),
(4,'5_391f3d70013d42ba','pageId_5'),
(5,'3_8430574af61b5cd5','pageId_3');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'2__0_0_1_1',1763531900,'x��VK��6�+���֞L�9-�m�P�%���Ŧ!��J�$�`�{i�,%)��(���-��ȏd䁼qR<3�^�7E$y�=s��l��JJ+�i�Y7`��7�\"ZZM)+��k���b:�&Y-h0Vr��W�x\"Z�Z�<�Ǡ�bdC�\Zh#ň�+��,��)!5���r�X�H2)��@����鋵\0׭(�h�Ψ��-뛑5@]�FW��-�LB��`%FY����ڤa��X:��u�G?r��-{ٖ��y�a$?fl��d�vҨ�B��:�[��Xy���g1�[��i������լQ���\rJ֋����-�������\\�Z��N�a�*ʴ�A��Bȹ�ܫZ�֪�wf�]��H�V�7WTq\rR���G!+w�-6=-k�і)�u��������b�STc���+�#I��^���^�G��Eۊcy_�)H\n�,�V\r��b�à��4��%\0�pi�(h�)�)5h��j�Z�_)>H�O��mG�����8�\"��k�%-��-^�l��?�>r��CK&����+�$x(��YzЋW�Eԛ��*�X��&�73����StT g�+7U�^:�P�p���cf����؆��9XB���-����������+JE�R���u�VW8�h\'FT�#;�fx��@�훘�&껬K��OKǭ���\0@��۸l�ƥ�?&�� 횢r9������	�g�q�sR�Q�#��=v=�p�!sB���ml����d	5�\\�jƦ�(�0� ��b ��\\�nm`���@��Ȋ�\n�����f� 	/�	�0H7j��H:sf��%�41-G�ꑊ���|�<I`nk�b���?,/��\\�����L����3-��Q���m�-��n~$��4�$�}z�bL�\'�\"�� e�H�Dn�nh��yӇOܫާ���\"Y�[\"�����悸ڬ���x_��}A�/�߼ J��/���g�������J�=������7֊\"��ll�7���p�2�[+���97q�'),
(2,'1__0_0_0_0',1763531900,'x�uVM��(�/>o��I�������ak.�9�\"��P���I������Ð�ܬ�$=����sR�0�ےwC֤yS�pR�����-)�����ݶ�힫��[�u�,ĕ�~���ʎ\r��z9��gR�Wm-�!`xd�\"{R�@;�F�ސ���g��\\vӾ�f�X�D\n�._�Ԛ�+���\0\r�B����`��P�d7�踼��H!�Rҁi��6j�u�*lg\Z����\Z޶a;�Q����V��]�/��`Gc5���F{R:���3.rd����oj��aT��Ro��Ԭ>��3���F5�J�	*�<�B�4�pLI�\\�V��N�1�M´���pF��Y>�θ���U����Kb�g�����\r5܂V��|��E���^Һ��\nf�a*�&\0]=F���jF���ⅉe1�`�嗴!	R�V	�.�䲁k�0]���:��b��GG+�i8\r�j\0,&�i�+�3��S5=h}�j�V�9>h���7����4�3�c��:𤥰qŋ���؄����Z3������BBB��=���~CX%�Y�b�u�o�O�n�W(n�{CG�yYM�:�s�.&t]y������w�ñ\r����[�K���/�׿|�����IE�2���m�V��h�F\\HFu�Wdx��@1�]*o���W����ύ����~`�.7.���af��ܹ�&Ϥ���\Z��pb6+��Djy�}�&Q?��B�ұ��=Y�z�%�ʳ�|�/�4�H�Y�eY<Fy��ɝ�f��z����#�ꀢT�o���حH��a���2�H?\\�7�H>e�%̸�ʜ�T�}mLNbRiؒ��YJ�V�wb�͵�C�ck(*H�F1ë���t������5�2��D9͋\'({RfQ�C�{��&�=���]�??r78BJ��Hvc�����=�Ou86e��yad��>>�W)=�'),
(3,'2__0_0_0_0',1763955214,'x��VK��6�+���֞L�9-�m�P�%���Ŧ!��J�$�`�{i�,%)��(���-��ȏd䁼qR<3�^�7E$y�=s��l��JJ+�i�Y7`��7�\"ZZM)+��k���b:�&Y-h0Vr��W�x\"Z�Z�<�Ǡ�bdC�\Zh#ň�+��,��)!5���r�X�H2)��@����鋵\0׭(�h�Ψ��-뛑5@]�FW��-�LB��`%FY����ڤa��X:��u�G?r��-{ٖ��y�a$?fl��d�vҨ�B��:�[��Xy���g1�[��i������լQ���\rJ֋����-�������\\�Z��N�a�*ʴ�A��Bȹ�ܫZ�֪�wf�]��H�V�7WTq\rR���G!+w�-6=-k�і)�u��������b�STc���+�#I��^���^�G��Eۊcy_�)H\n�,�V\r��b�à��4��%\0�pi�(h�)�)5h��j�Z�_)>H�O��mG�����8�\"��k�%-��-^�l��?�>r��CK&����+�$x(��YzЋW�Eԛ��*�X��&�73����StT g�+7U�^:�P�p���cf����؆��9XB���-����������+JE�R���u�VW8�h\'FT�#;�fx��@�훘�&껬K��OKǭ���\0@��۸l�ƥ�?&�� 횢r9������	�g�q�sR�Q�#��=v=�p�!sB���ml����d	5�\\�jƦ�(�0� ��b ��\\�nm`���@��Ȋ�\n�����f� 	/�	�0H7j��H:sf��%�41-G�ꑊ���|�<I`nk�b���?,/��\\�����L����3-��Q���m�-��n~$��4�$�}z�bL�\'�\"�� e�H�Dn�nh��yӇOܫާ���\"Y�[\"�����悸ڬ���x_��}A�/�߼ J��/���g�������J�=������7֊\"��ll�7���p�2�[+���97q�'),
(4,'4__0_0_0_0',1763955214,'x��XɎ�6��@�,��f�3��!��{9�DɄ%Q!���F�{��\"�VsH�D7��VU�z|AK���①��H0���#C���ꌵ\0k�%i:\rd�M�K���Ό� ��#�F�()hMvI��#+\n�:�%��P�5�a���E��PRR\\	����(I�<Ʌbm58��\0��P\"����`�bN�jv�S5�On���W�k�V=�(��cJ�,mqGm�,y/r�^�:X\ri�fk��,�t�#�S_��}�ےU	D�sBR	�+k���E��iCXm��O����{5��^��3�Kr�)V���\r��;��-�I�k֞�h��no���7XWƀA�\r�O��Qc���ު1.�[��������C�5����I,���s��^�\\va��Z��6�5��[���p����\"��}mj�3�K��Τ�o�r��r\\��go���oIJD~4&��]�\0c\r�����a%(�b�6\r7=`��p�NMC:���i)��1�	W���{�������Ma��6i!,M�B�y���ԙ)��Q��]�n H���9����|���:�,�5�m�	�\Z���Ľ�������CƇ����>�?���v���\r������	�����O�|����Ow�\nl%��Uޫ���:p$ц�0:�.��^:w_�����2姿�-��F��n���i��	�~��{5�;�|.`�o�������\\�S��K�����L4�?�`�:�T��\r=�Cc׏O�o��0�#�_KQ��:�3���ù�D7,E��z�[�y%�ŕ	&c��h�����ݓ��� ��Ĵ@�#4�&�3�t�m�@1�i� G�ѕx*wˡ�n��q�.��߿�5�w�5ĭ5�gӸ8�e��y�CS���B��kt���x�ͻ��?�l���>��4Iþ�b*�/>bt7����^1.\"Ř��Ӈ��b�nֳb��g��)��{P��R߽bL�b���:\'�\\��,g��#�tB f�@L�\"��l5�Kq��m��Y �q��@��wDO��] �_xC��!��Y��$a�_I¡������ %�k�]�u�d��$��?�֬�'),
(5,'3__0_0_0_0',1763955214,'x��VK��6�+��ݮ�L�9-�E���Kf=	��8Bl�+ɓ�������@����f~�(�\"?��y�xbd�$���I6�*{�d�d��JJK�i�Y�`�����(�����5���b5jV$��\r�Jn�����$C�Rkނ��tU��I�ZK1����$��JHͻz�oQ�+H&��#�R�^s�7}�����-�uV�a]=�\Z����\n�5E�ўI���� ��^�{X�4��U|��9���=oJ��x�a$?gl��d�vҠ�B��Z��lYy���g1�[��i/�����լV���\rJ։����\r��P����\\Н-+àU�i��>�`��s+�W��	�U�b3l{̾�$<��\\��o���\Z�����BV�`S�;Z�\\F���~,��S�Z�OQ\r�s�c//�$��{�_;��t\'�F�Ȼ\nNAR�d�����U��-��~�S-���K�EAL��O��iYO�=V3�$|K�^r|J}vh3�DM�g�aE]\r.i1�l�b�e3T����k|Z2Y��U�^%�Cិ�҃�� ,���=xTi�Z�5�\r�����V�A��V}�=n�0�t:`(�p������~�c��VT�`	U�?6����>|����W��l���u9蘭�:p\"�V��Fv�\'�p�����1���wY���_�[}#��n۷qao\0ݩ~�MVA�5U��^�;�ƈ�Y~3��z��z&�G�]GQ\\�Ȕ���\'k2��4[B�\'��꟰q<�&�8��f��»:\'��D�y�=�$���\"u�16��-H��~�Ic\0�\r�(�I�Τ�\n�ԙf &樽BERҰ$�q�\'	��c1]̹����R�ȵ�����=.�>���L�Q�z�ݚܢ���r9P�KߧG.��0+���R��t��&K�7}��½�m�zE,�1��\"�\"X<�o����r���+�l������\"�W���(���\"��D��C��+Ᏼ��Jhz�X+��cC��֊���+�?�2��	Hr�'),
(6,'5__0_0_0_0',1763955214,'x��XKo�8�+��ݮhǏ(��-������F�e�%�:F���CEQ�\n�a[$X�4_�b�2{��e�u��AL:Q$w\"[�9�Ei	�:K�6�n-@6�t�.o6k\\�U���3�,)x�\rw���� ��7=p�%p�2FԼ��o��fɞ�R���ɒ4��Z*#��n\\��6�&K�<}�:W�5B�S_�\n^S����J@}ִbMٱ�So�[�7*�6�e�7fk٩<�G�6��A��X!��~;��֧�	Y�<\'������i��X/D�S3p9��!W����j�Uq�����������o#��>?��n������~w�����}�8���>@\0���1�ec��t�dM#��K��`!Vr�<RQ����R�2�\r�0�f-m��UsN0��w+�A�<�s���m M0V�K;�ot��:��@]u��\\��?���]�`����(}^X�Zj�-�ƾ�!�%�ɵ=@�ES��;�?���{�çt䤆����aȻ��@�ˍ�Ι*��0�T��6�Z[�Etc�O�\Z#����\Z�8��ې�V��Z$՜����g\n��Ȇ#?��*��.�=gZ��A�r�\0�:�6-z�B�\\ȉ\Z������f����r��������2$�64ߗ�8��ˏYڇ<�_�.iY@+��QplIhL9*���\n�c�-���!ak��4�t/�J��vۡ��4M�W�����F6\"g�Ds?\"�����s!XԾ��ݐ�$8}z���6�.>8�t1��La��v��l\\�f#��l$������v�!�p6z�ƣqE�`4nӵ���]�%o��E	�6���ꐋҙ��q�Q�e߫<4�h��>����rh���Y��s�|TQ�l�\rav�@!ގ:�BStRh3(E�������\'6,�fG���P�{>J�m�\"6�^�݉��cX���4���Hh�\r=�i�\Z�\Z jg;~��C��N�C�#x�x�����?nS#(���I��%�Fl�/�4�@\Zg�un���J��5S�t�\"�EL�(\"Ar������z����u�=�R�+E�R�+E������t��}�5��������D	ɯ���� �FS� {�U�_Qğ��R���2>��c�k');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'2__0_0_1_1','pageId_1'),
(2,'2__0_0_1_1','pageId_2'),
(3,'1__0_0_0_0','pageId_1'),
(4,'2__0_0_0_0','pageId_1'),
(5,'2__0_0_0_0','pageId_2'),
(6,'4__0_0_0_0','pageId_1'),
(7,'4__0_0_0_0','pageId_2'),
(8,'4__0_0_0_0','pageId_4'),
(9,'3__0_0_0_0','pageId_1'),
(10,'3__0_0_0_0','pageId_3'),
(11,'5__0_0_0_0','pageId_1'),
(12,'5__0_0_0_0','pageId_3'),
(13,'5__0_0_0_0','pageId_5');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_config`
--

DROP TABLE IF EXISTS `index_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_config` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `set_id` int(11) NOT NULL DEFAULT 0,
  `session_data` mediumtext DEFAULT NULL,
  `alternative_source_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `depth` int(10) unsigned NOT NULL DEFAULT 0,
  `table2index` varchar(255) NOT NULL DEFAULT '',
  `indexcfgs` longtext DEFAULT NULL,
  `get_params` varchar(255) NOT NULL DEFAULT '',
  `fieldlist` varchar(255) NOT NULL DEFAULT '',
  `externalUrl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `extensions` varchar(255) NOT NULL DEFAULT '',
  `url_deny` longtext DEFAULT NULL,
  `records_indexonchange` smallint(5) unsigned NOT NULL DEFAULT 0,
  `timer_next_indexing` bigint(20) NOT NULL DEFAULT 0,
  `timer_offset` bigint(20) NOT NULL DEFAULT 0,
  `timer_frequency` int(10) unsigned NOT NULL DEFAULT 0,
  `recordsbatch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_config`
--

LOCK TABLES `index_config` WRITE;
/*!40000 ALTER TABLE `index_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_fulltext`
--

DROP TABLE IF EXISTS `index_fulltext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_fulltext` (
  `phash` varchar(32) NOT NULL,
  `fulltextdata` mediumtext DEFAULT NULL,
  PRIMARY KEY (`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_fulltext`
--

LOCK TABLES `index_fulltext` WRITE;
/*!40000 ALTER TABLE `index_fulltext` DISABLE KEYS */;
INSERT INTO `index_fulltext` VALUES
('3d798c3f120fdabe32985de46a5fc2fd','Homepage TYPO3 Bootstrap Vite \r\n             \r\n                  \r\n             \r\n             \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                First page\r\n                             \r\n                            \r\n                                 \r\n                                     \r\n                                         \r\n                                            Overview: First page\r\n                                         \r\n                                     \r\n                                    \r\n                                         \r\n                                             \r\n                                                First subpage\r\n                                             \r\n                                         \r\n                                    \r\n                                 \r\n                            \r\n                         \r\n                    \r\n                         \r\n                             \r\n                                Second page\r\n                             \r\n                            \r\n                                 \r\n                                     \r\n                                         \r\n                                            Overview: Second page\r\n                                         \r\n                                     \r\n                                    \r\n                                         \r\n                                             \r\n                                                Second subpage\r\n                                             \r\n                                         \r\n                                    \r\n                                 \r\n                            \r\n                         \r\n                    \r\n                 \r\n             \r\n         \r\n     \r\n \r\n\r\n\r\n     \r\n         \r\n             Homepage \r\n\r\n            \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n         \n            \n\n    \n             \n                This is a testpage above\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines. \n For esse est percipi – to be is to be perceived. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\r\n\r\n            \r\n\r\n            \r\n                  \r\n            \r\n\r\n            \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n         \n            \n\n    \n             \n                This is a testpage below\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines. \n For esse est percipi – to be is to be perceived. \n Headline third level \n And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards. \n You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\r\n         \r\n     \r\n     \r\n         \r\n             © 2025 - TYPO3 Bootstrap Vite  '),
('3e239e3d69de4b3b36fcd34479259a89','Second subpage First page\r\n             \r\n            \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                First subpage\r\n                             \r\n                         \r\n                    \r\n                 \r\n            \r\n         \r\n    \r\n         \r\n             \r\n                Second page\r\n             \r\n            \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                Second subpage\r\n                             \r\n                         \r\n                    \r\n                 \r\n            \r\n         \r\n    \r\n \r\n\r\n \r\n     Second subpage \r\n\r\n      \r\n      \r\n\r\n    \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n                \n\n     It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines. \n For esse est percipi – to be is to be perceived. \n And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards. \n You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.  '),
('56ce185f3262c9101626cfd28a4127a4','First page TYPO3 Bootstrap Vite \r\n             \r\n                  \r\n             \r\n             \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                First page\r\n                             \r\n                            \r\n                                 \r\n                                     \r\n                                         \r\n                                            Overview: First page\r\n                                         \r\n                                     \r\n                                    \r\n                                         \r\n                                             \r\n                                                First subpage\r\n                                             \r\n                                         \r\n                                    \r\n                                 \r\n                            \r\n                         \r\n                    \r\n                         \r\n                             \r\n                                Second page\r\n                             \r\n                            \r\n                                 \r\n                                     \r\n                                         \r\n                                            Overview: Second page\r\n                                         \r\n                                     \r\n                                    \r\n                                         \r\n                                             \r\n                                                Second subpage\r\n                                             \r\n                                         \r\n                                    \r\n                                 \r\n                            \r\n                         \r\n                    \r\n                 \r\n             \r\n         \r\n     \r\n \r\n\r\n\r\n     \r\n         \r\n             First page \r\n\r\n            \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n                \n\n     It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines. \n For esse est percipi – to be is to be perceived. \n And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards. \n You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\r\n\r\n \r\n\n     \n          \n     \n\r\n\r\n\r\n\r\n\r\n\r\n            \r\n\r\n            \r\n\r\n            \r\n         \r\n     \r\n     \r\n         \r\n             © 2025 - TYPO3 Bootstrap Vite  '),
('6d2ddd1174e062f12957e8f7a89bafb1','First subpage First page\r\n             \r\n            \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                First subpage\r\n                             \r\n                         \r\n                    \r\n                 \r\n            \r\n         \r\n    \r\n         \r\n             \r\n                Second page\r\n             \r\n            \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                Second subpage\r\n                             \r\n                         \r\n                    \r\n                 \r\n            \r\n         \r\n    \r\n \r\n\r\n \r\n     First subpage \r\n\r\n      \r\n      \r\n\r\n    \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n                \n\n     It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines. \n For esse est percipi – to be is to be perceived. \n And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards. \n You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.  '),
('78cabd40e1e1f417b9f83789c2321f4a','Second page First page\r\n             \r\n            \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                First subpage\r\n                             \r\n                         \r\n                    \r\n                 \r\n            \r\n         \r\n    \r\n         \r\n             \r\n                Second page\r\n             \r\n            \r\n                 \r\n                    \r\n                         \r\n                             \r\n                                Second subpage\r\n                             \r\n                         \r\n                    \r\n                 \r\n            \r\n         \r\n    \r\n \r\n\r\n \r\n     Second page \r\n\r\n      \r\n      \r\n\r\n    \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n                \n\n     It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines. \n For esse est percipi – to be is to be perceived. \n And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards. \n You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.  ');
/*!40000 ALTER TABLE `index_fulltext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_grlist`
--

DROP TABLE IF EXISTS `index_grlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_grlist` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` varchar(32) NOT NULL,
  `phash_x` varchar(32) NOT NULL,
  `hash_gr_list` varchar(32) NOT NULL,
  `gr_list` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`hash_gr_list`),
  KEY `phash_grouping` (`phash_x`,`hash_gr_list`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_grlist`
--

LOCK TABLES `index_grlist` WRITE;
/*!40000 ALTER TABLE `index_grlist` DISABLE KEYS */;
INSERT INTO `index_grlist` VALUES
(15,'6d2ddd1174e062f12957e8f7a89bafb1','6d2ddd1174e062f12957e8f7a89bafb1','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(17,'78cabd40e1e1f417b9f83789c2321f4a','78cabd40e1e1f417b9f83789c2321f4a','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(18,'3e239e3d69de4b3b36fcd34479259a89','3e239e3d69de4b3b36fcd34479259a89','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(27,'3d798c3f120fdabe32985de46a5fc2fd','3d798c3f120fdabe32985de46a5fc2fd','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(37,'56ce185f3262c9101626cfd28a4127a4','56ce185f3262c9101626cfd28a4127a4','cdc0a8f9fe7f5e206d167723a90af880','0,-1');
/*!40000 ALTER TABLE `index_grlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_phash`
--

DROP TABLE IF EXISTS `index_phash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_phash` (
  `phash` varchar(32) NOT NULL,
  `phash_grouping` varchar(32) NOT NULL,
  `static_page_arguments` blob DEFAULT NULL,
  `data_filename` varchar(1024) NOT NULL DEFAULT '',
  `data_page_id` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_type` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_mp` varchar(255) NOT NULL DEFAULT '',
  `gr_list` varchar(255) NOT NULL DEFAULT '',
  `item_type` varchar(5) NOT NULL DEFAULT '',
  `item_title` varchar(255) NOT NULL DEFAULT '',
  `item_description` varchar(255) NOT NULL DEFAULT '',
  `item_mtime` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `item_size` int(11) NOT NULL DEFAULT 0,
  `contentHash` varchar(32) NOT NULL,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `parsetime` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `item_crdate` int(11) NOT NULL DEFAULT 0,
  `externalUrl` smallint(6) NOT NULL DEFAULT 0,
  `recordUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexSetId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`),
  KEY `phash_grouping` (`phash_grouping`),
  KEY `freeIndexUid` (`freeIndexUid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_phash`
--

LOCK TABLES `index_phash` WRITE;
/*!40000 ALTER TABLE `index_phash` DISABLE KEYS */;
INSERT INTO `index_phash` VALUES
('3d798c3f120fdabe32985de46a5fc2fd','dc91fa3918f3fab9a43a16f82bb27086','[]','',1,0,'','0,-1','0','Homepage','TYPO3 Bootstrap Vite First page Overview: First page First subpage Second page Overview: Second page Second subpage Homepage This is a testpage above It\'s the same old story everywhere. The layout is ',1760779148,1761363214,7738,'7605fdb0580d6eb1e9d2771f5e1c832f',1760850711,21,0,1760768635,0,0,0,0),
('3e239e3d69de4b3b36fcd34479259a89','8a6ef888a6fc754ec9234c30e393cb8f','[]','',5,0,'','0,-1','0','Second subpage','First page First subpage Second page Second subpage Second subpage It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in ',1760803476,1761365700,3988,'8681af3814a4caf20c5c3d39f0577f66',1760803558,14,0,1760803473,0,0,0,0),
('56ce185f3262c9101626cfd28a4127a4','cadd9455631c2005b0784198b1c7f739','[]','',2,0,'','0,-1','0','First page','TYPO3 Bootstrap Vite First page Overview: First page First subpage Second page Overview: Second page Second subpage First page It\'s the same old story everywhere. The layout is ready, but the text is ',1760803095,1761365690,6846,'5f073b7b492ca546d82d43ddc6a6b6c5',1760863306,8,0,1760779531,0,0,0,0),
('6d2ddd1174e062f12957e8f7a89bafb1','42a44c80384793445371a8816cb755cc','[]','',4,0,'','0,-1','0','First subpage','First page First subpage Second page Second subpage First subpage It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in t',1760803458,1761365692,3983,'d7e3973984b76f2507ec0cb69deb32fa',1760803550,11,0,1760803431,0,0,0,0),
('78cabd40e1e1f417b9f83789c2321f4a','17e3c529abc7b537c5fcf59f12035044','[]','',3,0,'','0,-1','0','Second page','First page First subpage Second page Second subpage Second page It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the',1760803111,1761365701,3958,'6933001ae469685d01991691ecfb2105',1760803556,19,0,1760779571,0,0,0,0);
/*!40000 ALTER TABLE `index_phash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_rel`
--

DROP TABLE IF EXISTS `index_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_rel` (
  `phash` varchar(32) NOT NULL,
  `wid` varchar(32) NOT NULL,
  `count` smallint(5) unsigned NOT NULL DEFAULT 0,
  `first` int(10) unsigned NOT NULL DEFAULT 0,
  `freq` smallint(5) unsigned NOT NULL DEFAULT 0,
  `flags` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`,`wid`),
  KEY `wid` (`wid`,`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_rel`
--

LOCK TABLES `index_rel` WRITE;
/*!40000 ALTER TABLE `index_rel` DISABLE KEYS */;
INSERT INTO `index_rel` VALUES
('3d798c3f120fdabe32985de46a5fc2fd','01b6e20344b68835c5ed1ddedf20d531',11,39,12988,0),
('3d798c3f120fdabe32985de46a5fc2fd','059397100c3816785bce3cb425520171',1,211,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','07cc694b9b3fc636710fa08b6922c42b',2,79,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','07ccfe360dce69b84595428e2ec1c1cc',1,205,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','0cc175b9c0f1b6a831c399e269772661',7,20,8265,0),
('3d798c3f120fdabe32985de46a5fc2fd','0f635d0e0f3874fff8b581c132e6c7a7',1,243,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','13b5bfe96f3e2fe411c9f66f4a582adf',6,46,7084,0),
('3d798c3f120fdabe32985de46a5fc2fd','149603e6c03516362a8da23f624db945',2,26,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','1c52bdae8bad70e82da799843bb4e831',2,87,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','1cb251ec0d568de6a929b520c4aed8d1',4,35,4723,0),
('3d798c3f120fdabe32985de46a5fc2fd','1dd6473a75df4ac65f0911dbafee927f',1,231,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','1e8e42b87a65326b98ced7d3af717a72',1,221,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','20cc39187933346eee8108ec76a2f796',1,198,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','21582c6c30be1217322cdb9aebaf4a59',2,210,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','2567a5ec9705eb7ac2c984033e06189d',2,218,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','275876e34cf609db118f3d84b799a790',2,58,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','2764ca9d34e90313978d044f27ae433b',2,55,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','2dfc97e5e093b4b339ad510433d2e9ff',2,45,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','2f44417567bc123bd7c60de8c2a2b444',1,252,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','312351bff07989769097660a56395065',1,266,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','37598dad8f8805ce708ba8c4f67ce367',3,33,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','383c9968e79cb9a21d3cdde052a86acf',1,248,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','3bf1114a986ba87ed28fc1b5884fc2f8',2,68,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','3dd5cc4bc10007cc82043363ff7c42ea',2,21,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','4015e9ce43edfb0668ddaa973ebc7e87',4,178,4723,0),
('3d798c3f120fdabe32985de46a5fc2fd','437b930db84b8079c2dd804a71936b5f',1,209,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','4587c4183c312dd82309be6cdae7bbd6',2,86,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','492bd93456b81ad92f61e8891174ed04',1,259,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','4d066bbb0e40abe54f3000755a45aa6e',2,64,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','4da066daaf634712e6c48a5eb72cd9c3',2,2,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','50324905c471f3d4d61f7d3f723f3644',1,176,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','51037a4a37730f52c8732586d3aaa316',2,25,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','55a9d6aa251e3c334db4ab4055a4a004',1,22,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','589b397ed82131bf51acdf63521c2df5',1,233,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','5e8edd851d2fdfbd7415232c67367cc3',1,251,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','600d6af0f320a021dc494cfa2daca569',1,194,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','6299ba2cbd9661a5e3872b715521cd6a',1,200,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','62cc0b4ebb0b57b40778179234246c38',1,250,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','639bae9ac6b3e1a84cebb7b403297b79',5,80,5904,0),
('3d798c3f120fdabe32985de46a5fc2fd','6864f389d9876436bc8778ff071d1b6c',2,70,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','6a99c575ab87f8c7d1ed1e52e7e349ce',1,203,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','6cede1cfde12fc6d88ad1d8b6636a977',1,99,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','706dc2ee585fb5dcb18e3ac08da7ce0c',2,23,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','71860c77c6745379b0d44304d66b6a13',4,4,4723,0),
('3d798c3f120fdabe32985de46a5fc2fd','78ee54aa8f813885fe2fe20d232518b9',1,207,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','7c3daa31f887c333291d5cf04e541db5',3,83,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','7c6c2e5d48ab37a007cbf70d3ea25fa4',2,38,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','8134b84030cca5285ed0e0b31ba06f10',1,215,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','83ab982dd08483187289a75163dc50fe',2,78,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','860d7a9915c3d84e711f7dddfd9b4341',1,258,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','865c0c0b4ab0e063e5caa3387c1a8741',5,54,5904,0),
('3d798c3f120fdabe32985de46a5fc2fd','89759e1284e2479b991d2669de104942',1,244,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','8aaab33740413527c3d6f2be39c6ed2c',1,196,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','8b04d5e3775d298e78455efc5ca404d5',3,3,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','8b7af514f25f1f9456dcd10d2337f753',1,230,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','8bf8854bebe108183caeb845c7676ae4',4,69,4723,0),
('3d798c3f120fdabe32985de46a5fc2fd','8fc42c6ddf9966db3b09e84365034357',16,24,18892,0),
('3d798c3f120fdabe32985de46a5fc2fd','8fe3c4c25d511fbb31fcabeae0abb892',1,183,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','910955a907e739b81ec8855763108a29',5,90,5904,0),
('3d798c3f120fdabe32985de46a5fc2fd','97bc592b27a9ada2d9a4bb418ed0ebed',1,179,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','980da98409d058c365664ff7ea33dd6b',2,84,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','9a4b6f884971dcb4a5172876b335baab',1,246,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','9b0c41a084ce77bc23b6d8c06c77d953',2,40,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','9b6e831e4933640dcfd786a25f0b8c21',2,9,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','9cc49ff7cdca6cb5a0646f1e962943a4',1,189,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','9e925e9341b490bfd3b4c4ca3b0c1ef2',5,18,5904,0),
('3d798c3f120fdabe32985de46a5fc2fd','a22d960a29f7c4eda82959f1987bade2',3,94,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','a2a551a6458a8de22446cc76d639a9e9',8,19,9446,0),
('3d798c3f120fdabe32985de46a5fc2fd','a2e4822a98337283e39f7b60acf85ec9',2,53,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','a4f86f7bfc24194b276c22e0ef158197',2,228,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','a9f0e61a137d86aa9db53465e0801612',3,10,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','ab86a1e1ef70dff97959067b723c5c24',1,184,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','addec426932e71323700afa1911f8f1c',1,188,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','af3b39c56df7a42bdd1644db7a4c057d',2,77,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','b2fdab230a2c39f3595a947861863cb7',2,32,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','b42dad5453b2128a32f6612b13ea5d9f',1,247,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','ba3988db0a3167093b1f74e8ae4a8e83',2,0,2361,128),
('3d798c3f120fdabe32985de46a5fc2fd','bc1e98f4152cea98dfbb60fee42b91ff',2,88,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','bce059749d61c1c247c303d0118d0d53',2,5,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,253,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','be1ab1632e4285edc3733b142935c60b',1,192,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','be5d5d37542d75f93a87094459f76678',6,49,7084,0),
('3d798c3f120fdabe32985de46a5fc2fd','bec670e5a55424d840db8636ecc28828',2,27,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','c04cd38aeb30f3ad1f8ab4e64a0ded7b',2,76,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','c61404957758dfda283709e89376ab3e',4,30,4723,0),
('3d798c3f120fdabe32985de46a5fc2fd','c68271a63ddbc431c307beb7d2918275',2,208,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','c7a628cba22e28eb17b5f5c6ae2a266a',1,239,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','c9e9a848920877e76685b2e4e76de38d',1,174,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','ca4c50b905dc21ea17a10549a6f5944f',2,1,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','cbebc850f5f849e8956b5f8075f48f69',2,28,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','cc935c5faf4c8f7a0468d7552a9b8138',1,242,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','cdaeeeba9b4a4c5ebf042c0215a7bb0e',1,226,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','d00413cdded7a5c5bc2e06079d63e562',1,255,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','d1befa03c79ca0b84ecc488dea96bc68',1,265,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','d2e16e6ef52a45b7468f1da56bba1953',2,73,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','d529e941509eb9e9b9cfaeae1fe7ca23',1,199,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','d55669822f1a8cf72ec1911e462a54eb',6,62,7084,0),
('3d798c3f120fdabe32985de46a5fc2fd','d850f04cdb48312a9be171e214c0b4ee',1,234,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','d861877da56b8b4ceb35c8cbfdf65bb4',2,71,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','d939aaf7d2291c6f69ceecee94880d7c',1,180,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','d98a07f84921b24ee30f86fd8cd85c3c',3,43,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','dc117c9322deb502c3b16769a8a64e08',2,0,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','dd5c8bf51558ffcbe5007071908e9524',1,173,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','de9b9ed78d7e2e1dceeffee780e2f919',1,240,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','df55340f75b5da454e1c189d56d7f31b',2,37,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','e2fa538867c3830a859a5b17ab24644b',2,60,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','e511e2a4a4b88e45e210c770b932afb7',2,72,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','e680afd37e4511a8cb3ce9f63168862a',1,191,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','e78f5438b48b39bcbdea61b73679449d',2,74,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','eb5c1399a871211c7e7ed732d15e3a8b',2,51,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','ecae13117d6f0584c25a9da6c8f8415e',2,81,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','ed2b5c0139cec8ad2873829dc1117d50',1,229,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','ed881bac6397ede33c0a285c9f50bb83',1,257,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','ed8c35a1ac48075e6d39385ae0362958',2,50,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','edc1e3ea2ca4939a55f1edf84a1fb85e',1,181,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','ee288f745ff123bea93659882cb5ee57',3,219,3542,0),
('3d798c3f120fdabe32985de46a5fc2fd','eeeaea9366c4a3ee8ae10bffc661799e',2,44,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','ef56b0b0ddb93c2885892c06be830c68',1,217,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','ef983058688ff58732b0fe2b8779fc0a',1,172,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','f7c0a09108cdf26287c1bc5af2ed1f93',1,261,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','f8d5619dce76ee38cf24c4da2cec84ca',2,61,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','f970e2767d0cfe75876ea857f92e319b',2,201,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','f9f90eeaf400d228facde6bc48da5cfb',2,65,2361,0),
('3d798c3f120fdabe32985de46a5fc2fd','fc35fdc70d5fc69d269883a822c7a53e',1,238,1180,0),
('3d798c3f120fdabe32985de46a5fc2fd','fef2576d54dbde017a3a8e4df699ef6d',2,48,2361,0),
('3e239e3d69de4b3b36fcd34479259a89','01b6e20344b68835c5ed1ddedf20d531',8,26,14628,0),
('3e239e3d69de4b3b36fcd34479259a89','059397100c3816785bce3cb425520171',1,118,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','07cc694b9b3fc636710fa08b6922c42b',1,66,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','07ccfe360dce69b84595428e2ec1c1cc',1,112,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','0cc175b9c0f1b6a831c399e269772661',4,69,7314,0),
('3e239e3d69de4b3b36fcd34479259a89','0f635d0e0f3874fff8b581c132e6c7a7',1,150,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','13b5bfe96f3e2fe411c9f66f4a582adf',3,33,5485,0),
('3e239e3d69de4b3b36fcd34479259a89','149603e6c03516362a8da23f624db945',1,13,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','1c52bdae8bad70e82da799843bb4e831',1,74,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','1cb251ec0d568de6a929b520c4aed8d1',2,22,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','1dd6473a75df4ac65f0911dbafee927f',1,138,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','1e8e42b87a65326b98ced7d3af717a72',1,128,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','20cc39187933346eee8108ec76a2f796',1,105,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','21582c6c30be1217322cdb9aebaf4a59',2,117,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','2567a5ec9705eb7ac2c984033e06189d',2,125,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','275876e34cf609db118f3d84b799a790',1,45,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','2764ca9d34e90313978d044f27ae433b',1,42,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','2dfc97e5e093b4b339ad510433d2e9ff',1,32,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','2f44417567bc123bd7c60de8c2a2b444',1,159,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','37598dad8f8805ce708ba8c4f67ce367',2,20,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','383c9968e79cb9a21d3cdde052a86acf',1,155,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','3bf1114a986ba87ed28fc1b5884fc2f8',1,55,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','4015e9ce43edfb0668ddaa973ebc7e87',4,85,7314,0),
('3e239e3d69de4b3b36fcd34479259a89','437b930db84b8079c2dd804a71936b5f',1,116,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','4587c4183c312dd82309be6cdae7bbd6',1,73,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','492bd93456b81ad92f61e8891174ed04',1,166,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','4d066bbb0e40abe54f3000755a45aa6e',1,51,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','50324905c471f3d4d61f7d3f723f3644',1,83,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','51037a4a37730f52c8732586d3aaa316',1,12,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','589b397ed82131bf51acdf63521c2df5',1,140,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','5e8edd851d2fdfbd7415232c67367cc3',1,158,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','600d6af0f320a021dc494cfa2daca569',1,101,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','6299ba2cbd9661a5e3872b715521cd6a',1,107,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','62cc0b4ebb0b57b40778179234246c38',1,157,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','639bae9ac6b3e1a84cebb7b403297b79',4,67,7314,0),
('3e239e3d69de4b3b36fcd34479259a89','6864f389d9876436bc8778ff071d1b6c',1,57,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','6a99c575ab87f8c7d1ed1e52e7e349ce',1,110,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','706dc2ee585fb5dcb18e3ac08da7ce0c',1,10,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','71860c77c6745379b0d44304d66b6a13',2,1,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','78ee54aa8f813885fe2fe20d232518b9',1,114,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','7c3daa31f887c333291d5cf04e541db5',2,70,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','7c6c2e5d48ab37a007cbf70d3ea25fa4',1,25,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','8134b84030cca5285ed0e0b31ba06f10',1,122,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','83ab982dd08483187289a75163dc50fe',1,65,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','860d7a9915c3d84e711f7dddfd9b4341',1,165,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','865c0c0b4ab0e063e5caa3387c1a8741',3,41,5485,0),
('3e239e3d69de4b3b36fcd34479259a89','89759e1284e2479b991d2669de104942',1,151,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','8aaab33740413527c3d6f2be39c6ed2c',1,103,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','8b04d5e3775d298e78455efc5ca404d5',2,0,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','8b7af514f25f1f9456dcd10d2337f753',1,137,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','8bf8854bebe108183caeb845c7676ae4',3,56,5485,0),
('3e239e3d69de4b3b36fcd34479259a89','8fc42c6ddf9966db3b09e84365034357',9,11,16457,0),
('3e239e3d69de4b3b36fcd34479259a89','8fe3c4c25d511fbb31fcabeae0abb892',1,90,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','910955a907e739b81ec8855763108a29',3,77,5485,0),
('3e239e3d69de4b3b36fcd34479259a89','97bc592b27a9ada2d9a4bb418ed0ebed',1,86,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','980da98409d058c365664ff7ea33dd6b',1,71,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','9a4b6f884971dcb4a5172876b335baab',1,153,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','9b0c41a084ce77bc23b6d8c06c77d953',1,27,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','9b6e831e4933640dcfd786a25f0b8c21',4,0,7314,128),
('3e239e3d69de4b3b36fcd34479259a89','9cc49ff7cdca6cb5a0646f1e962943a4',1,96,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','9e925e9341b490bfd3b4c4ca3b0c1ef2',2,50,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','a22d960a29f7c4eda82959f1987bade2',2,81,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','a2a551a6458a8de22446cc76d639a9e9',3,18,5485,0),
('3e239e3d69de4b3b36fcd34479259a89','a2e4822a98337283e39f7b60acf85ec9',1,40,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','a4f86f7bfc24194b276c22e0ef158197',2,135,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','a9f0e61a137d86aa9db53465e0801612',4,0,7314,128),
('3e239e3d69de4b3b36fcd34479259a89','ab86a1e1ef70dff97959067b723c5c24',1,91,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','acefc2e6211c99bc063e7638a5459167',1,172,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','addec426932e71323700afa1911f8f1c',1,95,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','af3b39c56df7a42bdd1644db7a4c057d',1,64,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','b2fdab230a2c39f3595a947861863cb7',1,19,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','b42dad5453b2128a32f6612b13ea5d9f',1,154,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','bc1e98f4152cea98dfbb60fee42b91ff',1,75,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,160,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','be1ab1632e4285edc3733b142935c60b',1,99,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','be5d5d37542d75f93a87094459f76678',4,36,7314,0),
('3e239e3d69de4b3b36fcd34479259a89','bec670e5a55424d840db8636ecc28828',1,14,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','c04cd38aeb30f3ad1f8ab4e64a0ded7b',1,63,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','c61404957758dfda283709e89376ab3e',2,17,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','c68271a63ddbc431c307beb7d2918275',2,115,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','c7a628cba22e28eb17b5f5c6ae2a266a',1,146,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','cbebc850f5f849e8956b5f8075f48f69',1,15,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','cc935c5faf4c8f7a0468d7552a9b8138',1,149,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','cdaeeeba9b4a4c5ebf042c0215a7bb0e',1,133,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d00413cdded7a5c5bc2e06079d63e562',1,162,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d2e16e6ef52a45b7468f1da56bba1953',1,60,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d529e941509eb9e9b9cfaeae1fe7ca23',1,106,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d55669822f1a8cf72ec1911e462a54eb',4,49,7314,0),
('3e239e3d69de4b3b36fcd34479259a89','d850f04cdb48312a9be171e214c0b4ee',1,141,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d861877da56b8b4ceb35c8cbfdf65bb4',1,58,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d939aaf7d2291c6f69ceecee94880d7c',1,87,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','d98a07f84921b24ee30f86fd8cd85c3c',2,30,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','de9b9ed78d7e2e1dceeffee780e2f919',1,147,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','df55340f75b5da454e1c189d56d7f31b',1,24,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','e2fa538867c3830a859a5b17ab24644b',1,47,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','e511e2a4a4b88e45e210c770b932afb7',1,59,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','e680afd37e4511a8cb3ce9f63168862a',1,98,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','e78f5438b48b39bcbdea61b73679449d',1,61,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','eb5c1399a871211c7e7ed732d15e3a8b',1,38,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','ecae13117d6f0584c25a9da6c8f8415e',1,68,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','ed2b5c0139cec8ad2873829dc1117d50',1,136,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','ed881bac6397ede33c0a285c9f50bb83',1,164,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','ed8c35a1ac48075e6d39385ae0362958',1,37,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','edc1e3ea2ca4939a55f1edf84a1fb85e',1,88,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','ee288f745ff123bea93659882cb5ee57',3,126,5485,0),
('3e239e3d69de4b3b36fcd34479259a89','eeeaea9366c4a3ee8ae10bffc661799e',1,31,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','ef56b0b0ddb93c2885892c06be830c68',1,124,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','f7c0a09108cdf26287c1bc5af2ed1f93',1,168,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','f8d5619dce76ee38cf24c4da2cec84ca',1,48,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','f970e2767d0cfe75876ea857f92e319b',2,108,3657,0),
('3e239e3d69de4b3b36fcd34479259a89','f9f90eeaf400d228facde6bc48da5cfb',1,52,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','fc35fdc70d5fc69d269883a822c7a53e',1,145,1828,0),
('3e239e3d69de4b3b36fcd34479259a89','fef2576d54dbde017a3a8e4df699ef6d',1,35,1828,0),
('56ce185f3262c9101626cfd28a4127a4','01b6e20344b68835c5ed1ddedf20d531',8,35,13617,0),
('56ce185f3262c9101626cfd28a4127a4','059397100c3816785bce3cb425520171',1,127,1702,0),
('56ce185f3262c9101626cfd28a4127a4','07cc694b9b3fc636710fa08b6922c42b',1,75,1702,0),
('56ce185f3262c9101626cfd28a4127a4','07ccfe360dce69b84595428e2ec1c1cc',1,121,1702,0),
('56ce185f3262c9101626cfd28a4127a4','0cc175b9c0f1b6a831c399e269772661',4,78,6808,0),
('56ce185f3262c9101626cfd28a4127a4','0f635d0e0f3874fff8b581c132e6c7a7',1,159,1702,0),
('56ce185f3262c9101626cfd28a4127a4','13b5bfe96f3e2fe411c9f66f4a582adf',3,42,5106,0),
('56ce185f3262c9101626cfd28a4127a4','149603e6c03516362a8da23f624db945',1,22,1702,0),
('56ce185f3262c9101626cfd28a4127a4','1c52bdae8bad70e82da799843bb4e831',1,83,1702,0),
('56ce185f3262c9101626cfd28a4127a4','1cb251ec0d568de6a929b520c4aed8d1',2,31,3404,0),
('56ce185f3262c9101626cfd28a4127a4','1dd6473a75df4ac65f0911dbafee927f',1,147,1702,0),
('56ce185f3262c9101626cfd28a4127a4','1e8e42b87a65326b98ced7d3af717a72',1,137,1702,0),
('56ce185f3262c9101626cfd28a4127a4','20cc39187933346eee8108ec76a2f796',1,114,1702,0),
('56ce185f3262c9101626cfd28a4127a4','21582c6c30be1217322cdb9aebaf4a59',2,126,3404,0),
('56ce185f3262c9101626cfd28a4127a4','2567a5ec9705eb7ac2c984033e06189d',2,134,3404,0),
('56ce185f3262c9101626cfd28a4127a4','275876e34cf609db118f3d84b799a790',1,54,1702,0),
('56ce185f3262c9101626cfd28a4127a4','2764ca9d34e90313978d044f27ae433b',1,51,1702,0),
('56ce185f3262c9101626cfd28a4127a4','2dfc97e5e093b4b339ad510433d2e9ff',1,41,1702,0),
('56ce185f3262c9101626cfd28a4127a4','2f44417567bc123bd7c60de8c2a2b444',1,168,1702,0),
('56ce185f3262c9101626cfd28a4127a4','312351bff07989769097660a56395065',1,182,1702,0),
('56ce185f3262c9101626cfd28a4127a4','37598dad8f8805ce708ba8c4f67ce367',2,29,3404,0),
('56ce185f3262c9101626cfd28a4127a4','383c9968e79cb9a21d3cdde052a86acf',1,164,1702,0),
('56ce185f3262c9101626cfd28a4127a4','3bf1114a986ba87ed28fc1b5884fc2f8',1,64,1702,0),
('56ce185f3262c9101626cfd28a4127a4','4015e9ce43edfb0668ddaa973ebc7e87',4,94,6808,0),
('56ce185f3262c9101626cfd28a4127a4','437b930db84b8079c2dd804a71936b5f',1,125,1702,0),
('56ce185f3262c9101626cfd28a4127a4','4587c4183c312dd82309be6cdae7bbd6',1,82,1702,0),
('56ce185f3262c9101626cfd28a4127a4','492bd93456b81ad92f61e8891174ed04',1,175,1702,0),
('56ce185f3262c9101626cfd28a4127a4','4d066bbb0e40abe54f3000755a45aa6e',1,60,1702,0),
('56ce185f3262c9101626cfd28a4127a4','4da066daaf634712e6c48a5eb72cd9c3',2,2,3404,0),
('56ce185f3262c9101626cfd28a4127a4','50324905c471f3d4d61f7d3f723f3644',1,92,1702,0),
('56ce185f3262c9101626cfd28a4127a4','51037a4a37730f52c8732586d3aaa316',1,21,1702,0),
('56ce185f3262c9101626cfd28a4127a4','589b397ed82131bf51acdf63521c2df5',1,149,1702,0),
('56ce185f3262c9101626cfd28a4127a4','5e8edd851d2fdfbd7415232c67367cc3',1,167,1702,0),
('56ce185f3262c9101626cfd28a4127a4','600d6af0f320a021dc494cfa2daca569',1,110,1702,0),
('56ce185f3262c9101626cfd28a4127a4','6299ba2cbd9661a5e3872b715521cd6a',1,116,1702,0),
('56ce185f3262c9101626cfd28a4127a4','62cc0b4ebb0b57b40778179234246c38',1,166,1702,0),
('56ce185f3262c9101626cfd28a4127a4','639bae9ac6b3e1a84cebb7b403297b79',4,76,6808,0),
('56ce185f3262c9101626cfd28a4127a4','6864f389d9876436bc8778ff071d1b6c',1,66,1702,0),
('56ce185f3262c9101626cfd28a4127a4','6a99c575ab87f8c7d1ed1e52e7e349ce',1,119,1702,0),
('56ce185f3262c9101626cfd28a4127a4','706dc2ee585fb5dcb18e3ac08da7ce0c',1,19,1702,0),
('56ce185f3262c9101626cfd28a4127a4','71860c77c6745379b0d44304d66b6a13',6,0,10212,128),
('56ce185f3262c9101626cfd28a4127a4','78ee54aa8f813885fe2fe20d232518b9',1,123,1702,0),
('56ce185f3262c9101626cfd28a4127a4','7c3daa31f887c333291d5cf04e541db5',2,79,3404,0),
('56ce185f3262c9101626cfd28a4127a4','7c6c2e5d48ab37a007cbf70d3ea25fa4',1,34,1702,0),
('56ce185f3262c9101626cfd28a4127a4','8134b84030cca5285ed0e0b31ba06f10',1,131,1702,0),
('56ce185f3262c9101626cfd28a4127a4','83ab982dd08483187289a75163dc50fe',1,74,1702,0),
('56ce185f3262c9101626cfd28a4127a4','860d7a9915c3d84e711f7dddfd9b4341',1,174,1702,0),
('56ce185f3262c9101626cfd28a4127a4','865c0c0b4ab0e063e5caa3387c1a8741',3,50,5106,0),
('56ce185f3262c9101626cfd28a4127a4','89759e1284e2479b991d2669de104942',1,160,1702,0),
('56ce185f3262c9101626cfd28a4127a4','8aaab33740413527c3d6f2be39c6ed2c',1,112,1702,0),
('56ce185f3262c9101626cfd28a4127a4','8b04d5e3775d298e78455efc5ca404d5',5,0,8510,128),
('56ce185f3262c9101626cfd28a4127a4','8b7af514f25f1f9456dcd10d2337f753',1,146,1702,0),
('56ce185f3262c9101626cfd28a4127a4','8bf8854bebe108183caeb845c7676ae4',3,65,5106,0),
('56ce185f3262c9101626cfd28a4127a4','8fc42c6ddf9966db3b09e84365034357',9,20,15319,0),
('56ce185f3262c9101626cfd28a4127a4','8fe3c4c25d511fbb31fcabeae0abb892',1,99,1702,0),
('56ce185f3262c9101626cfd28a4127a4','910955a907e739b81ec8855763108a29',3,86,5106,0),
('56ce185f3262c9101626cfd28a4127a4','97bc592b27a9ada2d9a4bb418ed0ebed',1,95,1702,0),
('56ce185f3262c9101626cfd28a4127a4','980da98409d058c365664ff7ea33dd6b',1,80,1702,0),
('56ce185f3262c9101626cfd28a4127a4','9a4b6f884971dcb4a5172876b335baab',1,162,1702,0),
('56ce185f3262c9101626cfd28a4127a4','9b0c41a084ce77bc23b6d8c06c77d953',1,36,1702,0),
('56ce185f3262c9101626cfd28a4127a4','9b6e831e4933640dcfd786a25f0b8c21',2,9,3404,0),
('56ce185f3262c9101626cfd28a4127a4','9cc49ff7cdca6cb5a0646f1e962943a4',1,105,1702,0),
('56ce185f3262c9101626cfd28a4127a4','9e925e9341b490bfd3b4c4ca3b0c1ef2',2,59,3404,0),
('56ce185f3262c9101626cfd28a4127a4','a22d960a29f7c4eda82959f1987bade2',2,90,3404,0),
('56ce185f3262c9101626cfd28a4127a4','a2a551a6458a8de22446cc76d639a9e9',3,27,5106,0),
('56ce185f3262c9101626cfd28a4127a4','a2e4822a98337283e39f7b60acf85ec9',1,49,1702,0),
('56ce185f3262c9101626cfd28a4127a4','a4f86f7bfc24194b276c22e0ef158197',2,144,3404,0),
('56ce185f3262c9101626cfd28a4127a4','a9f0e61a137d86aa9db53465e0801612',3,10,5106,0),
('56ce185f3262c9101626cfd28a4127a4','ab86a1e1ef70dff97959067b723c5c24',1,100,1702,0),
('56ce185f3262c9101626cfd28a4127a4','addec426932e71323700afa1911f8f1c',1,104,1702,0),
('56ce185f3262c9101626cfd28a4127a4','af3b39c56df7a42bdd1644db7a4c057d',1,73,1702,0),
('56ce185f3262c9101626cfd28a4127a4','b2fdab230a2c39f3595a947861863cb7',1,28,1702,0),
('56ce185f3262c9101626cfd28a4127a4','b42dad5453b2128a32f6612b13ea5d9f',1,163,1702,0),
('56ce185f3262c9101626cfd28a4127a4','bc1e98f4152cea98dfbb60fee42b91ff',1,84,1702,0),
('56ce185f3262c9101626cfd28a4127a4','bce059749d61c1c247c303d0118d0d53',2,5,3404,0),
('56ce185f3262c9101626cfd28a4127a4','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,169,1702,0),
('56ce185f3262c9101626cfd28a4127a4','be1ab1632e4285edc3733b142935c60b',1,108,1702,0),
('56ce185f3262c9101626cfd28a4127a4','be5d5d37542d75f93a87094459f76678',4,45,6808,0),
('56ce185f3262c9101626cfd28a4127a4','bec670e5a55424d840db8636ecc28828',1,23,1702,0),
('56ce185f3262c9101626cfd28a4127a4','c04cd38aeb30f3ad1f8ab4e64a0ded7b',1,72,1702,0),
('56ce185f3262c9101626cfd28a4127a4','c61404957758dfda283709e89376ab3e',2,26,3404,0),
('56ce185f3262c9101626cfd28a4127a4','c68271a63ddbc431c307beb7d2918275',2,124,3404,0),
('56ce185f3262c9101626cfd28a4127a4','c7a628cba22e28eb17b5f5c6ae2a266a',1,155,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ca4c50b905dc21ea17a10549a6f5944f',2,1,3404,0),
('56ce185f3262c9101626cfd28a4127a4','cbebc850f5f849e8956b5f8075f48f69',1,24,1702,0),
('56ce185f3262c9101626cfd28a4127a4','cc935c5faf4c8f7a0468d7552a9b8138',1,158,1702,0),
('56ce185f3262c9101626cfd28a4127a4','cdaeeeba9b4a4c5ebf042c0215a7bb0e',1,142,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d00413cdded7a5c5bc2e06079d63e562',1,171,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d1befa03c79ca0b84ecc488dea96bc68',1,181,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d2e16e6ef52a45b7468f1da56bba1953',1,69,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d529e941509eb9e9b9cfaeae1fe7ca23',1,115,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d55669822f1a8cf72ec1911e462a54eb',4,58,6808,0),
('56ce185f3262c9101626cfd28a4127a4','d850f04cdb48312a9be171e214c0b4ee',1,150,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d861877da56b8b4ceb35c8cbfdf65bb4',1,67,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d939aaf7d2291c6f69ceecee94880d7c',1,96,1702,0),
('56ce185f3262c9101626cfd28a4127a4','d98a07f84921b24ee30f86fd8cd85c3c',2,39,3404,0),
('56ce185f3262c9101626cfd28a4127a4','dc117c9322deb502c3b16769a8a64e08',2,0,3404,0),
('56ce185f3262c9101626cfd28a4127a4','de9b9ed78d7e2e1dceeffee780e2f919',1,156,1702,0),
('56ce185f3262c9101626cfd28a4127a4','df55340f75b5da454e1c189d56d7f31b',1,33,1702,0),
('56ce185f3262c9101626cfd28a4127a4','e2fa538867c3830a859a5b17ab24644b',1,56,1702,0),
('56ce185f3262c9101626cfd28a4127a4','e511e2a4a4b88e45e210c770b932afb7',1,68,1702,0),
('56ce185f3262c9101626cfd28a4127a4','e680afd37e4511a8cb3ce9f63168862a',1,107,1702,0),
('56ce185f3262c9101626cfd28a4127a4','e78f5438b48b39bcbdea61b73679449d',1,70,1702,0),
('56ce185f3262c9101626cfd28a4127a4','eb5c1399a871211c7e7ed732d15e3a8b',1,47,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ecae13117d6f0584c25a9da6c8f8415e',1,77,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ed2b5c0139cec8ad2873829dc1117d50',1,145,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ed881bac6397ede33c0a285c9f50bb83',1,173,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ed8c35a1ac48075e6d39385ae0362958',1,46,1702,0),
('56ce185f3262c9101626cfd28a4127a4','edc1e3ea2ca4939a55f1edf84a1fb85e',1,97,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ee288f745ff123bea93659882cb5ee57',3,135,5106,0),
('56ce185f3262c9101626cfd28a4127a4','eeeaea9366c4a3ee8ae10bffc661799e',1,40,1702,0),
('56ce185f3262c9101626cfd28a4127a4','ef56b0b0ddb93c2885892c06be830c68',1,133,1702,0),
('56ce185f3262c9101626cfd28a4127a4','f7c0a09108cdf26287c1bc5af2ed1f93',1,177,1702,0),
('56ce185f3262c9101626cfd28a4127a4','f8d5619dce76ee38cf24c4da2cec84ca',1,57,1702,0),
('56ce185f3262c9101626cfd28a4127a4','f970e2767d0cfe75876ea857f92e319b',2,117,3404,0),
('56ce185f3262c9101626cfd28a4127a4','f9f90eeaf400d228facde6bc48da5cfb',1,61,1702,0),
('56ce185f3262c9101626cfd28a4127a4','fc35fdc70d5fc69d269883a822c7a53e',1,154,1702,0),
('56ce185f3262c9101626cfd28a4127a4','fef2576d54dbde017a3a8e4df699ef6d',1,44,1702,0),
('6d2ddd1174e062f12957e8f7a89bafb1','01b6e20344b68835c5ed1ddedf20d531',8,26,14628,0),
('6d2ddd1174e062f12957e8f7a89bafb1','059397100c3816785bce3cb425520171',1,118,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','07cc694b9b3fc636710fa08b6922c42b',1,66,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','07ccfe360dce69b84595428e2ec1c1cc',1,112,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','0cc175b9c0f1b6a831c399e269772661',4,69,7314,0),
('6d2ddd1174e062f12957e8f7a89bafb1','0f635d0e0f3874fff8b581c132e6c7a7',1,150,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','13b5bfe96f3e2fe411c9f66f4a582adf',3,33,5485,0),
('6d2ddd1174e062f12957e8f7a89bafb1','149603e6c03516362a8da23f624db945',1,13,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','1c52bdae8bad70e82da799843bb4e831',1,74,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','1cb251ec0d568de6a929b520c4aed8d1',2,22,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','1dd6473a75df4ac65f0911dbafee927f',1,138,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','1e8e42b87a65326b98ced7d3af717a72',1,128,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','20cc39187933346eee8108ec76a2f796',1,105,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','21582c6c30be1217322cdb9aebaf4a59',2,117,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','2567a5ec9705eb7ac2c984033e06189d',2,125,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','275876e34cf609db118f3d84b799a790',1,45,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','2764ca9d34e90313978d044f27ae433b',1,42,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','2dfc97e5e093b4b339ad510433d2e9ff',1,32,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','2f44417567bc123bd7c60de8c2a2b444',1,159,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','37598dad8f8805ce708ba8c4f67ce367',2,20,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','383c9968e79cb9a21d3cdde052a86acf',1,155,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','3bf1114a986ba87ed28fc1b5884fc2f8',1,55,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','4015e9ce43edfb0668ddaa973ebc7e87',4,85,7314,0),
('6d2ddd1174e062f12957e8f7a89bafb1','437b930db84b8079c2dd804a71936b5f',1,116,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','4587c4183c312dd82309be6cdae7bbd6',1,73,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','492bd93456b81ad92f61e8891174ed04',1,166,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','4d066bbb0e40abe54f3000755a45aa6e',1,51,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','50324905c471f3d4d61f7d3f723f3644',1,83,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','51037a4a37730f52c8732586d3aaa316',1,12,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','589b397ed82131bf51acdf63521c2df5',1,140,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','5e8edd851d2fdfbd7415232c67367cc3',1,158,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','600d6af0f320a021dc494cfa2daca569',1,101,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','6299ba2cbd9661a5e3872b715521cd6a',1,107,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','62cc0b4ebb0b57b40778179234246c38',1,157,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','639bae9ac6b3e1a84cebb7b403297b79',4,67,7314,0),
('6d2ddd1174e062f12957e8f7a89bafb1','6864f389d9876436bc8778ff071d1b6c',1,57,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','6a99c575ab87f8c7d1ed1e52e7e349ce',1,110,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','706dc2ee585fb5dcb18e3ac08da7ce0c',1,10,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','71860c77c6745379b0d44304d66b6a13',2,1,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','78ee54aa8f813885fe2fe20d232518b9',1,114,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','7c3daa31f887c333291d5cf04e541db5',2,70,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','7c6c2e5d48ab37a007cbf70d3ea25fa4',1,25,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','8134b84030cca5285ed0e0b31ba06f10',1,122,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','83ab982dd08483187289a75163dc50fe',1,65,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','860d7a9915c3d84e711f7dddfd9b4341',1,165,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','865c0c0b4ab0e063e5caa3387c1a8741',3,41,5485,0),
('6d2ddd1174e062f12957e8f7a89bafb1','89759e1284e2479b991d2669de104942',1,151,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','8aaab33740413527c3d6f2be39c6ed2c',1,103,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','8b04d5e3775d298e78455efc5ca404d5',4,0,7314,128),
('6d2ddd1174e062f12957e8f7a89bafb1','8b7af514f25f1f9456dcd10d2337f753',1,137,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','8bf8854bebe108183caeb845c7676ae4',3,56,5485,0),
('6d2ddd1174e062f12957e8f7a89bafb1','8fc42c6ddf9966db3b09e84365034357',9,11,16457,0),
('6d2ddd1174e062f12957e8f7a89bafb1','8fe3c4c25d511fbb31fcabeae0abb892',1,90,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','910955a907e739b81ec8855763108a29',3,77,5485,0),
('6d2ddd1174e062f12957e8f7a89bafb1','97bc592b27a9ada2d9a4bb418ed0ebed',1,86,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','980da98409d058c365664ff7ea33dd6b',1,71,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','9a4b6f884971dcb4a5172876b335baab',1,153,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','9b0c41a084ce77bc23b6d8c06c77d953',1,27,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','9b6e831e4933640dcfd786a25f0b8c21',4,0,7314,128),
('6d2ddd1174e062f12957e8f7a89bafb1','9cc49ff7cdca6cb5a0646f1e962943a4',1,96,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','9e925e9341b490bfd3b4c4ca3b0c1ef2',2,50,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','a22d960a29f7c4eda82959f1987bade2',2,81,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','a2a551a6458a8de22446cc76d639a9e9',3,18,5485,0),
('6d2ddd1174e062f12957e8f7a89bafb1','a2e4822a98337283e39f7b60acf85ec9',1,40,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','a4f86f7bfc24194b276c22e0ef158197',2,135,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','a9f0e61a137d86aa9db53465e0801612',2,4,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ab86a1e1ef70dff97959067b723c5c24',1,91,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','acefc2e6211c99bc063e7638a5459167',1,172,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','addec426932e71323700afa1911f8f1c',1,95,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','af3b39c56df7a42bdd1644db7a4c057d',1,64,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','b2fdab230a2c39f3595a947861863cb7',1,19,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','b42dad5453b2128a32f6612b13ea5d9f',1,154,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','bc1e98f4152cea98dfbb60fee42b91ff',1,75,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,160,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','be1ab1632e4285edc3733b142935c60b',1,99,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','be5d5d37542d75f93a87094459f76678',4,36,7314,0),
('6d2ddd1174e062f12957e8f7a89bafb1','bec670e5a55424d840db8636ecc28828',1,14,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','c04cd38aeb30f3ad1f8ab4e64a0ded7b',1,63,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','c61404957758dfda283709e89376ab3e',2,17,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','c68271a63ddbc431c307beb7d2918275',2,115,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','c7a628cba22e28eb17b5f5c6ae2a266a',1,146,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','cbebc850f5f849e8956b5f8075f48f69',1,15,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','cc935c5faf4c8f7a0468d7552a9b8138',1,149,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','cdaeeeba9b4a4c5ebf042c0215a7bb0e',1,133,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d00413cdded7a5c5bc2e06079d63e562',1,162,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d2e16e6ef52a45b7468f1da56bba1953',1,60,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d529e941509eb9e9b9cfaeae1fe7ca23',1,106,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d55669822f1a8cf72ec1911e462a54eb',4,49,7314,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d850f04cdb48312a9be171e214c0b4ee',1,141,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d861877da56b8b4ceb35c8cbfdf65bb4',1,58,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d939aaf7d2291c6f69ceecee94880d7c',1,87,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d98a07f84921b24ee30f86fd8cd85c3c',2,30,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','de9b9ed78d7e2e1dceeffee780e2f919',1,147,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','df55340f75b5da454e1c189d56d7f31b',1,24,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e2fa538867c3830a859a5b17ab24644b',1,47,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e511e2a4a4b88e45e210c770b932afb7',1,59,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e680afd37e4511a8cb3ce9f63168862a',1,98,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e78f5438b48b39bcbdea61b73679449d',1,61,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','eb5c1399a871211c7e7ed732d15e3a8b',1,38,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ecae13117d6f0584c25a9da6c8f8415e',1,68,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ed2b5c0139cec8ad2873829dc1117d50',1,136,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ed881bac6397ede33c0a285c9f50bb83',1,164,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ed8c35a1ac48075e6d39385ae0362958',1,37,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','edc1e3ea2ca4939a55f1edf84a1fb85e',1,88,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ee288f745ff123bea93659882cb5ee57',3,126,5485,0),
('6d2ddd1174e062f12957e8f7a89bafb1','eeeaea9366c4a3ee8ae10bffc661799e',1,31,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ef56b0b0ddb93c2885892c06be830c68',1,124,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','f7c0a09108cdf26287c1bc5af2ed1f93',1,168,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','f8d5619dce76ee38cf24c4da2cec84ca',1,48,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','f970e2767d0cfe75876ea857f92e319b',2,108,3657,0),
('6d2ddd1174e062f12957e8f7a89bafb1','f9f90eeaf400d228facde6bc48da5cfb',1,52,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','fc35fdc70d5fc69d269883a822c7a53e',1,145,1828,0),
('6d2ddd1174e062f12957e8f7a89bafb1','fef2576d54dbde017a3a8e4df699ef6d',1,35,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','01b6e20344b68835c5ed1ddedf20d531',8,26,14628,0),
('78cabd40e1e1f417b9f83789c2321f4a','059397100c3816785bce3cb425520171',1,118,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','07cc694b9b3fc636710fa08b6922c42b',1,66,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','07ccfe360dce69b84595428e2ec1c1cc',1,112,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','0cc175b9c0f1b6a831c399e269772661',4,69,7314,0),
('78cabd40e1e1f417b9f83789c2321f4a','0f635d0e0f3874fff8b581c132e6c7a7',1,150,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','13b5bfe96f3e2fe411c9f66f4a582adf',3,33,5485,0),
('78cabd40e1e1f417b9f83789c2321f4a','149603e6c03516362a8da23f624db945',1,13,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','1c52bdae8bad70e82da799843bb4e831',1,74,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','1cb251ec0d568de6a929b520c4aed8d1',2,22,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','1dd6473a75df4ac65f0911dbafee927f',1,138,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','1e8e42b87a65326b98ced7d3af717a72',1,128,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','20cc39187933346eee8108ec76a2f796',1,105,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','21582c6c30be1217322cdb9aebaf4a59',2,117,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','2567a5ec9705eb7ac2c984033e06189d',2,125,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','275876e34cf609db118f3d84b799a790',1,45,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','2764ca9d34e90313978d044f27ae433b',1,42,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','2dfc97e5e093b4b339ad510433d2e9ff',1,32,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','2f44417567bc123bd7c60de8c2a2b444',1,159,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','37598dad8f8805ce708ba8c4f67ce367',2,20,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','383c9968e79cb9a21d3cdde052a86acf',1,155,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','3bf1114a986ba87ed28fc1b5884fc2f8',1,55,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','4015e9ce43edfb0668ddaa973ebc7e87',4,85,7314,0),
('78cabd40e1e1f417b9f83789c2321f4a','437b930db84b8079c2dd804a71936b5f',1,116,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','4587c4183c312dd82309be6cdae7bbd6',1,73,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','492bd93456b81ad92f61e8891174ed04',1,166,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','4d066bbb0e40abe54f3000755a45aa6e',1,51,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','50324905c471f3d4d61f7d3f723f3644',1,83,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','51037a4a37730f52c8732586d3aaa316',1,12,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','589b397ed82131bf51acdf63521c2df5',1,140,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','5e8edd851d2fdfbd7415232c67367cc3',1,158,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','600d6af0f320a021dc494cfa2daca569',1,101,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','6299ba2cbd9661a5e3872b715521cd6a',1,107,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','62cc0b4ebb0b57b40778179234246c38',1,157,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','639bae9ac6b3e1a84cebb7b403297b79',4,67,7314,0),
('78cabd40e1e1f417b9f83789c2321f4a','6864f389d9876436bc8778ff071d1b6c',1,57,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','6a99c575ab87f8c7d1ed1e52e7e349ce',1,110,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','706dc2ee585fb5dcb18e3ac08da7ce0c',1,10,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','71860c77c6745379b0d44304d66b6a13',4,0,7314,128),
('78cabd40e1e1f417b9f83789c2321f4a','78ee54aa8f813885fe2fe20d232518b9',1,114,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','7c3daa31f887c333291d5cf04e541db5',2,70,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','7c6c2e5d48ab37a007cbf70d3ea25fa4',1,25,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','8134b84030cca5285ed0e0b31ba06f10',1,122,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','83ab982dd08483187289a75163dc50fe',1,65,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','860d7a9915c3d84e711f7dddfd9b4341',1,165,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','865c0c0b4ab0e063e5caa3387c1a8741',3,41,5485,0),
('78cabd40e1e1f417b9f83789c2321f4a','89759e1284e2479b991d2669de104942',1,151,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','8aaab33740413527c3d6f2be39c6ed2c',1,103,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','8b04d5e3775d298e78455efc5ca404d5',2,0,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','8b7af514f25f1f9456dcd10d2337f753',1,137,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','8bf8854bebe108183caeb845c7676ae4',3,56,5485,0),
('78cabd40e1e1f417b9f83789c2321f4a','8fc42c6ddf9966db3b09e84365034357',9,11,16457,0),
('78cabd40e1e1f417b9f83789c2321f4a','8fe3c4c25d511fbb31fcabeae0abb892',1,90,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','910955a907e739b81ec8855763108a29',3,77,5485,0),
('78cabd40e1e1f417b9f83789c2321f4a','97bc592b27a9ada2d9a4bb418ed0ebed',1,86,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','980da98409d058c365664ff7ea33dd6b',1,71,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','9a4b6f884971dcb4a5172876b335baab',1,153,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','9b0c41a084ce77bc23b6d8c06c77d953',1,27,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','9b6e831e4933640dcfd786a25f0b8c21',2,3,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','9cc49ff7cdca6cb5a0646f1e962943a4',1,96,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','9e925e9341b490bfd3b4c4ca3b0c1ef2',2,50,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','a22d960a29f7c4eda82959f1987bade2',2,81,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','a2a551a6458a8de22446cc76d639a9e9',3,18,5485,0),
('78cabd40e1e1f417b9f83789c2321f4a','a2e4822a98337283e39f7b60acf85ec9',1,40,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','a4f86f7bfc24194b276c22e0ef158197',2,135,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','a9f0e61a137d86aa9db53465e0801612',4,0,7314,128),
('78cabd40e1e1f417b9f83789c2321f4a','ab86a1e1ef70dff97959067b723c5c24',1,91,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','acefc2e6211c99bc063e7638a5459167',1,172,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','addec426932e71323700afa1911f8f1c',1,95,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','af3b39c56df7a42bdd1644db7a4c057d',1,64,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','b2fdab230a2c39f3595a947861863cb7',1,19,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','b42dad5453b2128a32f6612b13ea5d9f',1,154,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','bc1e98f4152cea98dfbb60fee42b91ff',1,75,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,160,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','be1ab1632e4285edc3733b142935c60b',1,99,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','be5d5d37542d75f93a87094459f76678',4,36,7314,0),
('78cabd40e1e1f417b9f83789c2321f4a','bec670e5a55424d840db8636ecc28828',1,14,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','c04cd38aeb30f3ad1f8ab4e64a0ded7b',1,63,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','c61404957758dfda283709e89376ab3e',2,17,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','c68271a63ddbc431c307beb7d2918275',2,115,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','c7a628cba22e28eb17b5f5c6ae2a266a',1,146,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','cbebc850f5f849e8956b5f8075f48f69',1,15,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','cc935c5faf4c8f7a0468d7552a9b8138',1,149,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','cdaeeeba9b4a4c5ebf042c0215a7bb0e',1,133,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d00413cdded7a5c5bc2e06079d63e562',1,162,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d2e16e6ef52a45b7468f1da56bba1953',1,60,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d529e941509eb9e9b9cfaeae1fe7ca23',1,106,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d55669822f1a8cf72ec1911e462a54eb',4,49,7314,0),
('78cabd40e1e1f417b9f83789c2321f4a','d850f04cdb48312a9be171e214c0b4ee',1,141,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d861877da56b8b4ceb35c8cbfdf65bb4',1,58,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d939aaf7d2291c6f69ceecee94880d7c',1,87,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','d98a07f84921b24ee30f86fd8cd85c3c',2,30,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','de9b9ed78d7e2e1dceeffee780e2f919',1,147,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','df55340f75b5da454e1c189d56d7f31b',1,24,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','e2fa538867c3830a859a5b17ab24644b',1,47,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','e511e2a4a4b88e45e210c770b932afb7',1,59,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','e680afd37e4511a8cb3ce9f63168862a',1,98,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','e78f5438b48b39bcbdea61b73679449d',1,61,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','eb5c1399a871211c7e7ed732d15e3a8b',1,38,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','ecae13117d6f0584c25a9da6c8f8415e',1,68,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','ed2b5c0139cec8ad2873829dc1117d50',1,136,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','ed881bac6397ede33c0a285c9f50bb83',1,164,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','ed8c35a1ac48075e6d39385ae0362958',1,37,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','edc1e3ea2ca4939a55f1edf84a1fb85e',1,88,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','ee288f745ff123bea93659882cb5ee57',3,126,5485,0),
('78cabd40e1e1f417b9f83789c2321f4a','eeeaea9366c4a3ee8ae10bffc661799e',1,31,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','ef56b0b0ddb93c2885892c06be830c68',1,124,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','f7c0a09108cdf26287c1bc5af2ed1f93',1,168,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','f8d5619dce76ee38cf24c4da2cec84ca',1,48,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','f970e2767d0cfe75876ea857f92e319b',2,108,3657,0),
('78cabd40e1e1f417b9f83789c2321f4a','f9f90eeaf400d228facde6bc48da5cfb',1,52,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','fc35fdc70d5fc69d269883a822c7a53e',1,145,1828,0),
('78cabd40e1e1f417b9f83789c2321f4a','fef2576d54dbde017a3a8e4df699ef6d',1,35,1828,0);
/*!40000 ALTER TABLE `index_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_section`
--

DROP TABLE IF EXISTS `index_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_section` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` varchar(32) NOT NULL,
  `phash_t3` varchar(32) NOT NULL,
  `rl0` int(10) unsigned NOT NULL DEFAULT 0,
  `rl1` int(10) unsigned NOT NULL DEFAULT 0,
  `rl2` int(10) unsigned NOT NULL DEFAULT 0,
  `page_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`rl0`),
  KEY `page_id` (`page_id`),
  KEY `rl0` (`rl0`,`rl1`,`phash`),
  KEY `rl0_2` (`rl0`,`phash`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_section`
--

LOCK TABLES `index_section` WRITE;
/*!40000 ALTER TABLE `index_section` DISABLE KEYS */;
INSERT INTO `index_section` VALUES
(15,'6d2ddd1174e062f12957e8f7a89bafb1','6d2ddd1174e062f12957e8f7a89bafb1',1,2,4,4),
(17,'78cabd40e1e1f417b9f83789c2321f4a','78cabd40e1e1f417b9f83789c2321f4a',1,3,0,3),
(18,'3e239e3d69de4b3b36fcd34479259a89','3e239e3d69de4b3b36fcd34479259a89',1,3,5,5),
(27,'3d798c3f120fdabe32985de46a5fc2fd','3d798c3f120fdabe32985de46a5fc2fd',1,0,0,1),
(37,'56ce185f3262c9101626cfd28a4127a4','56ce185f3262c9101626cfd28a4127a4',1,2,0,2);
/*!40000 ALTER TABLE `index_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_stat_word`
--

DROP TABLE IF EXISTS `index_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(50) NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tstamp` (`tstamp`,`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_stat_word`
--

LOCK TABLES `index_stat_word` WRITE;
/*!40000 ALTER TABLE `index_stat_word` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_stat_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_words`
--

DROP TABLE IF EXISTS `index_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_words` (
  `wid` varchar(32) NOT NULL,
  `baseword` varchar(60) NOT NULL DEFAULT '',
  `is_stopword` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`wid`),
  KEY `baseword` (`baseword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_words`
--

LOCK TABLES `index_words` WRITE;
/*!40000 ALTER TABLE `index_words` DISABLE KEYS */;
INSERT INTO `index_words` VALUES
('01b6e20344b68835c5ed1ddedf20d531','to',0),
('059397100c3816785bce3cb425520171','deserves',0),
('07cc694b9b3fc636710fa08b6922c42b','time',0),
('07ccfe360dce69b84595428e2ec1c1cc','also',0),
('0cc175b9c0f1b6a831c399e269772661','a',0),
('0f635d0e0f3874fff8b581c132e6c7a7','xml',0),
('106a6c241b8797f52e1e77317b96a201','home',0),
('13b5bfe96f3e2fe411c9f66f4a582adf','in',0),
('149603e6c03516362a8da23f624db945','old',0),
('1c52bdae8bad70e82da799843bb4e831','est',0),
('1cb251ec0d568de6a929b520c4aed8d1','text',0),
('1dd6473a75df4ac65f0911dbafee927f','websites',0),
('1e8e42b87a65326b98ced7d3af717a72','see',0),
('20cc39187933346eee8108ec76a2f796','serve',0),
('21582c6c30be1217322cdb9aebaf4a59','that',0),
('2492410d17d5e02fc71218ca9b67a23a','testseite',0),
('2567a5ec9705eb7ac2c984033e06189d','web',0),
('25f088fd210008a031306fdbb46bbad3','auf',0),
('275876e34cf609db118f3d84b799a790','dummy',0),
('2764ca9d34e90313978d044f27ae433b','step',0),
('2a6571da26602a67be14ea8c5ab82349','das',0),
('2dfc97e5e093b4b339ad510433d2e9ff','naked',0),
('2f44417567bc123bd7c60de8c2a2b444','before',0),
('312351bff07989769097660a56395065','2025',0),
('320f1ab4a00c60c5de82e547e0b95fd1','zweite',0),
('37598dad8f8805ce708ba8c4f67ce367','but',0),
('383c9968e79cb9a21d3cdde052a86acf','heard',0),
('3bf1114a986ba87ed28fc1b5884fc2f8','shadow',0),
('3dd5cc4bc10007cc82043363ff7c42ea','testpage',0),
('4015e9ce43edfb0668ddaa973ebc7e87','are',0),
('437b930db84b8079c2dd804a71936b5f','something',0),
('4587c4183c312dd82309be6cdae7bbd6','esse',0),
('492bd93456b81ad92f61e8891174ed04','gets',0),
('4d066bbb0e40abe54f3000755a45aa6e','purpose',0),
('4da066daaf634712e6c48a5eb72cd9c3','vite',0),
('50324905c471f3d4d61f7d3f723f3644','since',0),
('51037a4a37730f52c8732586d3aaa316','same',0),
('55a9d6aa251e3c334db4ab4055a4a004','above',0),
('589b397ed82131bf51acdf63521c2df5','built',0),
('5e8edd851d2fdfbd7415232c67367cc3','developer',0),
('600d6af0f320a021dc494cfa2daca569','take',0),
('6299ba2cbd9661a5e3872b715521cd6a','only',0),
('62cc0b4ebb0b57b40778179234246c38','your',0),
('639bae9ac6b3e1a84cebb7b403297b79','you',0),
('6864f389d9876436bc8778ff071d1b6c','my',0),
('6a99c575ab87f8c7d1ed1e52e7e349ce','placeholder',0),
('6b4a92b17faed1dd845e7bd26dbdf204','showdelete',0),
('6bd48b1e57856137037bfee4dec8d57f','der',0),
('6cede1cfde12fc6d88ad1d8b6636a977','below',0),
('706dc2ee585fb5dcb18e3ac08da7ce0c','it\'s',0),
('71860c77c6745379b0d44304d66b6a13','page',0),
('78ee54aa8f813885fe2fe20d232518b9','point',0),
('7c3daa31f887c333291d5cf04e541db5','few',0),
('7c6c2e5d48ab37a007cbf70d3ea25fa4','pending',0),
('8134b84030cca5285ed0e0b31ba06f10','just',0),
('83ab982dd08483187289a75163dc50fe','every',0),
('860d7a9915c3d84e711f7dddfd9b4341','involved',0),
('865c0c0b4ab0e063e5caa3387c1a8741','i',0),
('89759e1284e2479b991d2669de104942','words',0),
('8aaab33740413527c3d6f2be39c6ed2c','opportunity',0),
('8b04d5e3775d298e78455efc5ca404d5','first',0),
('8b7af514f25f1f9456dcd10d2337f753','which',0),
('8bf8854bebe108183caeb845c7676ae4','of',0),
('8fc42c6ddf9966db3b09e84365034357','the',0),
('8fe3c4c25d511fbb31fcabeae0abb892','accompany',0),
('910955a907e739b81ec8855763108a29','be',0),
('97bc592b27a9ada2d9a4bb418ed0ebed','now',0),
('980da98409d058c365664ff7ea33dd6b','lines',0),
('9a4b6f884971dcb4a5172876b335baab','may',0),
('9b0c41a084ce77bc23b6d8c06c77d953','prevent',0),
('9b6e831e4933640dcfd786a25f0b8c21','subpage',0),
('9cc49ff7cdca6cb5a0646f1e962943a4','sentences',0),
('9e925e9341b490bfd3b4c4ca3b0c1ef2','this',0),
('a22d960a29f7c4eda82959f1987bade2','perceived',0),
('a2a551a6458a8de22446cc76d639a9e9','is',0),
('a2e4822a98337283e39f7b60acf85ec9','empty',0),
('a4f86f7bfc24194b276c22e0ef158197','rules',0),
('a9f0e61a137d86aa9db53465e0801612','second',0),
('ab86a1e1ef70dff97959067b723c5c24','me',0),
('acefc2e6211c99bc063e7638a5459167','website.',0),
('ad42f6697b035b7580e4fef93be20b4d','debug',0),
('addec426932e71323700afa1911f8f1c','more',0),
('af3b39c56df7a42bdd1644db7a4c057d','delighted',0),
('b2fdab230a2c39f3595a947861863cb7','ready',0),
('b42dad5453b2128a32f6612b13ea5d9f','have',0),
('ba3988db0a3167093b1f74e8ae4a8e83','homepage',0),
('bc1e98f4152cea98dfbb60fee42b91ff','percipi',0),
('bce059749d61c1c247c303d0118d0d53','overview',0),
('bd4c4ea1b44a8ff2afa18dfd261ec2c8','these',0),
('be1ab1632e4285edc3733b142935c60b','like',0),
('be5d5d37542d75f93a87094459f76678','and',0),
('bec670e5a55424d840db8636ecc28828','story',0),
('c04cd38aeb30f3ad1f8ab4e64a0ded7b','am',0),
('c51ce410c124a10e0db5e4b97fc2af39','13',0),
('c61404957758dfda283709e89376ab3e','layout',0),
('c68271a63ddbc431c307beb7d2918275','out',0),
('c7a628cba22e28eb17b5f5c6ae2a266a','css',0),
('c9e9a848920877e76685b2e4e76de38d','level',0),
('ca4c50b905dc21ea17a10549a6f5944f','bootstrap',0),
('cbebc850f5f849e8956b5f8075f48f69','everywhere',0),
('cbf4f9f39b44ba3841673ec3fbea236d','eine',0),
('cc935c5faf4c8f7a0468d7552a9b8138','even',0),
('cd0d2905a7551dc7f9c63f4dde7c5924','willkommen',0),
('cdaeeeba9b4a4c5ebf042c0215a7bb0e','set',0),
('cea87c5766ad115d7843b828aaeb7264','unterseite',0),
('d00413cdded7a5c5bc2e06079d63e562','ensure',0),
('d1befa03c79ca0b84ecc488dea96bc68','website',0),
('d2e16e6ef52a45b7468f1da56bba1953','lorem',0),
('d529e941509eb9e9b9cfaeae1fe7ca23','not',0),
('d55669822f1a8cf72ec1911e462a54eb','for',0),
('d850f04cdb48312a9be171e214c0b4ee','there',0),
('d861877da56b8b4ceb35c8cbfdf65bb4','big',0),
('d939aaf7d2291c6f69ceecee94880d7c','kind',0),
('d98a07f84921b24ee30f86fd8cd85c3c','from',0),
('dc117c9322deb502c3b16769a8a64e08','typo3',0),
('dd5c8bf51558ffcbe5007071908e9524','third',0),
('de9b9ed78d7e2e1dceeffee780e2f919','javascript',0),
('df55340f75b5da454e1c189d56d7f31b','still',0),
('e2fa538867c3830a859a5b17ab24644b','created',0),
('e511e2a4a4b88e45e210c770b932afb7','brother',0),
('e5a93371cfc7eab4a88221dd1f6c1a3c','ist',0),
('e680afd37e4511a8cb3ce9f63168862a','would',0),
('e78f5438b48b39bcbdea61b73679449d','ipsum',0),
('eb5c1399a871211c7e7ed732d15e3a8b','small',0),
('ecae13117d6f0584c25a9da6c8f8415e','read',0),
('ed2b5c0139cec8ad2873829dc1117d50','on',0),
('ed881bac6397ede33c0a285c9f50bb83','everyone',0),
('ed8c35a1ac48075e6d39385ae0362958','feeling',0),
('edc1e3ea2ca4939a55f1edf84a1fb85e','enough',0),
('ee288f745ff123bea93659882cb5ee57','standards',0),
('eeeaea9366c4a3ee8ae10bffc661799e','standing',0),
('ef56b0b0ddb93c2885892c06be830c68','much',0),
('ef983058688ff58732b0fe2b8779fc0a','headline',0),
('f6d67619fc8eb5ab7c4462763bc90c8c','erste',0),
('f7c0a09108cdf26287c1bc5af2ed1f93','most',0),
('f8d5619dce76ee38cf24c4da2cec84ca','precisely',0),
('f970e2767d0cfe75876ea857f92e319b','as',0),
('f9f90eeaf400d228facde6bc48da5cfb','always',0),
('fad1d29bc9853626be4faf0f2171fd21','cardtitle',0),
('fc35fdc70d5fc69d269883a822c7a53e','html',0),
('fe01ce2a7fbac8fafaed7c982a04e229','demo',0),
('fef2576d54dbde017a3a8e4df699ef6d','room',0);
/*!40000 ALTER TABLE `index_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1760779148,1760768635,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1760779148,0,0,0,0,0.5,1,'Homepage','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__default','pagets__default',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1760803095,1760779531,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1760803095,0,0,0,0,0.5,1,'First page','/first-page',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(3,1,1760803111,1760779571,0,0,0,0,'',512,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1760803111,0,0,0,0,0.5,1,'Second page','/second-page',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(4,2,1760803458,1760803431,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,3,0,31,27,0,1760803458,0,0,0,0,0.5,1,'First subpage','/first-page/first-subpage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(5,3,1760803476,1760803473,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,1760803476,0,0,0,0,0.5,1,'Second subpage','/second-page/second-subpage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1760803769,1760803769,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1760761716,1760761716,0,1,5,'application/x-empty',0,0),
(2,0,1760850933,1760850933,'/_assets/f21e82d0f1e264cba24fa2cdb8a1505e/Icons/FileTypes/pages.gif','96dcc050af9761b9a5fab3e323b66989ace99ad1','15acd491ea28479e237caab4435b3864dbfb487d','gif','pages.gif','5c5fd7567caa18c3c6cff78996c73b78c2b77864',1760844218,1760768182,102,0,2,'image/gif',0,0),
(3,0,1760855810,1760855810,'/user_upload/logo.svg','3ae3e7283e2d8746cbe5e01d7fd5db9b105c89dc','19669f1e02c2f16705ec7587044c66443be70725','svg','logo.svg','f3a2daab091438bcf2e2d0ef4307def59c8ccb7c',1760855810,1760855810,1659,1,2,'image/svg+xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `status` varchar(24) DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `pages` int(10) unsigned DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `visible` smallint(5) unsigned NOT NULL DEFAULT 1,
  `keywords` longtext DEFAULT NULL,
  `caption` longtext DEFAULT NULL,
  `creator_tool` varchar(255) NOT NULL DEFAULT '',
  `download_name` varchar(255) NOT NULL DEFAULT '',
  `creator` varchar(255) NOT NULL DEFAULT '',
  `publisher` varchar(120) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `copyright` longtext DEFAULT NULL,
  `location_country` varchar(45) NOT NULL DEFAULT '',
  `location_region` varchar(45) NOT NULL DEFAULT '',
  `location_city` varchar(45) NOT NULL DEFAULT '',
  `ranking` int(10) unsigned NOT NULL DEFAULT 0,
  `content_creation_date` bigint(20) NOT NULL DEFAULT 0,
  `content_modification_date` bigint(20) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `unit` varchar(3) NOT NULL DEFAULT '',
  `duration` int(11) NOT NULL DEFAULT 0,
  `color_space` varchar(4) NOT NULL DEFAULT '',
  `language` varchar(45) NOT NULL DEFAULT '',
  `fe_groups` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1760803769,1760803769,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,1,NULL,0,0,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(2,0,1760850933,1760850933,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,2,NULL,18,16,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(3,0,1760855810,1760855810,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,3,NULL,410,404,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1760850933,1760850933,0,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','5c5fd7567caa18c3c6cff78996c73b78c2b77864','Image.CropScaleMask','f2c7c7d472',18,16),
(2,1760855810,1760855810,1,3,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','f3a2daab091438bcf2e2d0ef4307def59c8ccb7c','Image.Preview','6ed3d906df',64,63),
(3,1760855812,1760855812,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','f3a2daab091438bcf2e2d0ef4307def59c8ccb7c','Image.CropScaleMask','e9f8aacaf9',117,115),
(4,1760855823,1760855823,1,3,'/_processed_/d/3/csm_logo_16d305212b.svg','csm_logo_16d305212b.svg',NULL,'a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','f3a2daab091438bcf2e2d0ef4307def59c8ccb7c','Image.CropScaleMask','16d305212b',32,32),
(5,1760855824,1760855824,1,3,'/_processed_/d/3/csm_logo_f224cf24ff.svg','csm_logo_f224cf24ff.svg',NULL,'a:2:{s:5:\"width\";s:3:\"24c\";s:6:\"height\";s:3:\"24c\";}','82b22ab432074975de2bed394e641126f85ea53b','f3a2daab091438bcf2e2d0ef4307def59c8ccb7c','Image.CropScaleMask','f224cf24ff',24,24);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,0,1760855823,1760855823,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,3,'be_users','avatar',1,'',NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1760768643,1760768643,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(22,3,1760940406,'tt_content',2,2,'johndoe',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1760864879,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(2,1760864881,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(3,1760864887,3,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.6','[\"johndoe\"]',-1,0,'',0,'','info',NULL,NULL),
(4,1760866807,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.6','[\"johndoe\"]',-1,-99,'',0,'','info',NULL,NULL),
(5,1760884745,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.6','[\"johndoe\"]',-1,-99,'',0,'','info',NULL,NULL),
(6,1760884755,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(7,1760930208,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.6','[\"johndoe\"]',-1,-99,'',0,'','info',NULL,NULL),
(8,1760936233,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(9,1760936235,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(10,1760936594,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(11,1760937207,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(12,1760937209,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(13,1760937334,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(14,1760939163,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(15,1760939897,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"johndoe\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `source_host` varchar(255) NOT NULL DEFAULT '',
  `source_path` text NOT NULL DEFAULT '',
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` text NOT NULL DEFAULT '',
  `target_statuscode` int(10) unsigned NOT NULL DEFAULT 0,
  `lasthiton` bigint(20) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `creation_type` int(10) unsigned NOT NULL DEFAULT 0,
  `integrity_status` varchar(180) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('492dd930b8f60827688eb9f5332f18c9','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('59bf030b386143226b78e5414c0ab334','be_users',3,'avatar',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('72fd38b7b140a9a722298fd6ff58ab31','be_users',3,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'johm@doe.com'),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f9c64f1c71a8b40ffa94f38fcbb366b0','sys_file_metadata',1,'file',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'languagePacks','de-typo3_vite_demo','i:1760864821;'),
(2,'languagePacks','de','i:1760864823;'),
(4,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(11,'core','sys_refindex_lastUpdate','i:1760849980;'),
(15,'core','formProtectionSessionToken:3','s:64:\"2e90edfd1d63a8c27c89e88aa3767b06792c9ed987b5e7ec87c771fe48371e90\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1760850706,1760768990,0,0,0,0,256,'',0,'RootTemplate',1,3,'','EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/,EXT:typo3_vite_demo/Configuration/TypoScript','',0,'page {\r\n    config {\r\n        contentObjectExceptionHandler = 0   \r\n    }\r\n}',0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1760849328,1760769027,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'medium','medium',0,'This is a testpage above',2,'','','','<p>It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines.</p>\r\n<p>For esse est percipi – to be is to be perceived.</p>',0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(2,2,1760803529,1760803527,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'medium','medium',0,'This is a testpage',100,'','','','<p>It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines.</p>\r\n<p>For esse est percipi – to be is to be perceived.</p>\r\n<p>And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards.</p>\r\n<p>You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.</p>',0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(3,4,1760803535,1760803533,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'medium','medium',0,'This is a testpage',100,'','','','<p>It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines.</p>\r\n<p>For esse est percipi – to be is to be perceived.</p>\r\n<p>And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards.</p>\r\n<p>You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.</p>',0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(4,3,1760803541,1760803539,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'medium','medium',0,'This is a testpage',100,'','','','<p>It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines.</p>\r\n<p>For esse est percipi – to be is to be perceived.</p>\r\n<p>And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards.</p>\r\n<p>You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.</p>',0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(5,5,1760803547,1760803545,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'medium','medium',0,'This is a testpage',100,'','','','<p>It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines.</p>\r\n<p>For esse est percipi – to be is to be perceived.</p>\r\n<p>And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards.</p>\r\n<p>You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.</p>',0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(6,1,1760850644,1760847785,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',1,NULL,0,'text',0,0,'medium','large',0,'This is a testpage below',2,'','','','<p>It\'s the same old story everywhere. The layout is ready, but the text is still pending. To prevent the layout from standing naked in the room and feeling small and empty, I step in: the dummy text. Created precisely for this purpose, always in the shadow of my big brother ‘Lorem Ipsum’, I am delighted every time you read a few lines.</p>\r\n<p>For esse est percipi – to be is to be perceived.</p>\r\n<h3>Headline third level</h3>\r\n<p>And since you are now kind enough to accompany me for a few more sentences, I would like to take this opportunity to serve not only as a placeholder, but also to point out something that deserves to be perceived just as much: web standards.</p>\r\n<p>You see, web standards are the set of rules on which websites are built. There are rules for HTML, CSS, JavaScript and even XML; words you may have heard from your developer before. These standards ensure that everyone involved gets the most out of a website.</p>',0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(7,2,1760863305,1760851236,0,0,0,0,'',512,'',0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'typo3vitedemo_todolist',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"xmlTitle\">\n                    <value index=\"vDEF\">Testtitle</value>\n                </field>\n                <field index=\"settings.showDeleteButton\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.showFilter\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.showClearCompleted\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.maxItems\">\n                    <value index=\"vDEF\">50</value>\n                </field>\n                <field index=\"settings.predefinedItems\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"sAppearance\">\n            <language index=\"lDEF\">\n                <field index=\"settings.cardTitle\">\n                    <value index=\"vDEF\">Some new ToDo List</value>\n                </field>\n                <field index=\"settings.colorScheme\">\n                    <value index=\"vDEF\">primary</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT -1,
  `headline` varchar(255) NOT NULL DEFAULT '',
  `field` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `element_type` varchar(255) NOT NULL DEFAULT '',
  `link_title` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `url_response` text DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--

LOCK TABLES `tx_linkvalidator_link` WRITE;
/*!40000 ALTER TABLE `tx_linkvalidator_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_linkvalidator_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-10-25  4:22:05
